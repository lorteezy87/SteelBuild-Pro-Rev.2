import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Get all users
    const users = await base44.asServiceRole.entities.User.list();
    const allTasks = await base44.asServiceRole.entities.Task.list('-due_date', 500);
    const allProjects = await base44.asServiceRole.entities.Project.list();

    const projectMap = {};
    allProjects.forEach(p => { projectMap[p.id] = p; });

    const now = new Date();
    const in48h = new Date(now.getTime() + 48 * 60 * 60 * 1000);
    const in10d = new Date(now.getTime() + 10 * 24 * 60 * 60 * 1000);

    let emailsSent = 0;

    for (const user of users) {
      // Check if user has opted in to daily emails
      if (!user.daily_email_enabled) continue;

      // Get tasks relevant to this user (assigned or member of project)
      const userTasks = allTasks.filter(t => {
        if (t.status === 'completed') return false;
        if (t.assignee === user.email) return true;
        const project = projectMap[t.project_id];
        if (project?.members?.includes(user.email)) return true;
        return false;
      });

      const overdue = [];
      const due48h = [];
      const due10d = [];

      userTasks.forEach(task => {
        if (!task.due_date) return;
        const [year, month, day] = task.due_date.split('-').map(Number);
        const dueDate = new Date(year, month - 1, day, 23, 59, 59);

        if (dueDate < now) {
          overdue.push(task);
        } else if (dueDate <= in48h) {
          due48h.push(task);
        } else if (dueDate <= in10d) {
          due10d.push(task);
        }
      });

      if (overdue.length === 0 && due48h.length === 0 && due10d.length === 0) continue;

      // Build email HTML
      const taskRow = (task) => {
        const project = projectMap[task.project_id];
        return `<tr>
          <td style="padding:8px 12px;border-bottom:1px solid #2a2e3a;color:#e2e8f0;font-size:14px;">${task.title}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #2a2e3a;color:#94a3b8;font-size:13px;">${project?.name || '—'}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #2a2e3a;color:#94a3b8;font-size:13px;">${task.due_date}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #2a2e3a;font-size:12px;">
            <span style="padding:2px 8px;border-radius:4px;background:${task.priority === 'critical' ? '#7f1d1d' : task.priority === 'high' ? '#7c2d12' : task.priority === 'medium' ? '#78350f' : '#1e3a5f'};color:${task.priority === 'critical' ? '#fca5a5' : task.priority === 'high' ? '#fdba74' : task.priority === 'medium' ? '#fcd34d' : '#93c5fd'};">${(task.priority || 'medium').toUpperCase()}</span>
          </td>
        </tr>`;
      };

      const section = (title, color, tasks) => {
        if (tasks.length === 0) return '';
        return `
          <div style="margin-bottom:24px;">
            <h2 style="color:${color};font-size:16px;font-family:monospace;letter-spacing:2px;margin-bottom:12px;">${title} (${tasks.length})</h2>
            <table style="width:100%;border-collapse:collapse;background:#1a1e2a;border-radius:6px;overflow:hidden;">
              <thead>
                <tr style="background:#141824;">
                  <th style="text-align:left;padding:8px 12px;color:#64748b;font-size:11px;font-family:monospace;letter-spacing:1px;">TASK</th>
                  <th style="text-align:left;padding:8px 12px;color:#64748b;font-size:11px;font-family:monospace;letter-spacing:1px;">PROJECT</th>
                  <th style="text-align:left;padding:8px 12px;color:#64748b;font-size:11px;font-family:monospace;letter-spacing:1px;">DUE</th>
                  <th style="text-align:left;padding:8px 12px;color:#64748b;font-size:11px;font-family:monospace;letter-spacing:1px;">PRIORITY</th>
                </tr>
              </thead>
              <tbody>${tasks.map(taskRow).join('')}</tbody>
            </table>
          </div>`;
      };

      const emailBody = `
        <div style="background:#0f1219;padding:32px;font-family:'Inter',sans-serif;">
          <div style="max-width:600px;margin:0 auto;">
            <div style="margin-bottom:24px;">
              <h1 style="color:#e2e8f0;font-size:20px;font-weight:700;margin:0;">📋 Daily Task Summary</h1>
              <p style="color:#64748b;font-size:13px;font-family:monospace;margin-top:4px;">${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
            ${section('⚠️ OVERDUE', '#f87171', overdue)}
            ${section('🔥 DUE WITHIN 48 HOURS', '#fb923c', due48h)}
            ${section('📅 DUE WITHIN 10 DAYS', '#60a5fa', due10d)}
            <p style="color:#475569;font-size:12px;margin-top:24px;font-family:monospace;">You can disable these emails in BuildBoard Settings.</p>
          </div>
        </div>`;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: user.email,
        subject: `BuildBoard Daily Summary — ${overdue.length} overdue, ${due48h.length + due10d.length} upcoming`,
        body: emailBody,
        from_name: 'BuildBoard',
      });

      emailsSent++;
    }

    return Response.json({ success: true, emails_sent: emailsSent });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});