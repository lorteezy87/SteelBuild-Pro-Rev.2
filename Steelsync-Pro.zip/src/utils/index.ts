export function createPageUrl(pageName: string) {
    return '/' + pageName.replace(/ /g, '-');
}

/**
 * Parse a date string (YYYY-MM-DD) without timezone conversion.
 * Using new Date("2026-03-15") treats it as UTC midnight and shifts it
 * back one day in negative-offset timezones. This avoids that.
 */
export function parseLocalDate(dateStr: string): Date {
    if (!dateStr) return new Date(dateStr);
    const [year, month, day] = dateStr.split('-').map(Number);
    return new Date(year, month - 1, day);
}