import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Search, Plus, Filter } from 'lucide-react';

export default function TaskFilterBar({ search, setSearch, priority, setPriority, assignee, setAssignee, members = [], onNewTask }) {
  return (
    <div className="flex gap-2 flex-wrap items-center">
      <div className="relative flex-1 min-w-[180px] max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search tasks..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 h-8 text-xs"
        />
      </div>

      <Select value={priority} onValueChange={setPriority}>
        <SelectTrigger className="w-28 h-8 text-xs">
          <SelectValue placeholder="Priority" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Priority</SelectItem>
          <SelectItem value="critical">Critical</SelectItem>
          <SelectItem value="high">High</SelectItem>
          <SelectItem value="medium">Medium</SelectItem>
          <SelectItem value="low">Low</SelectItem>
        </SelectContent>
      </Select>

      {members.length > 0 && (
        <Select value={assignee} onValueChange={setAssignee}>
          <SelectTrigger className="w-36 h-8 text-xs">
            <SelectValue placeholder="Assignee" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Members</SelectItem>
            <SelectItem value="unassigned">Unassigned</SelectItem>
            {members.map(m => (
              <SelectItem key={m} value={m}>{m}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      <Button size="sm" className="h-8 gap-1.5 font-mono text-[10px] tracking-wider ml-auto" onClick={onNewTask}>
        <Plus className="w-3 h-3" /> ADD TASK
      </Button>
    </div>
  );
}