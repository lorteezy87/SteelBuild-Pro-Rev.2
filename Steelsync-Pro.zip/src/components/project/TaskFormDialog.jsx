import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Plus, X, Save, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const defaultForm = {
  title: '', description: '', status: 'todo', priority: 'medium',
  assignee: '', start_date: '', due_date: '', estimated_hours: '',
  actual_hours: '', tags: [], checklist: [], dependency_ids: [],
  is_recurring: false, recurrence_pattern: 'weekly',
};

export default function TaskFormDialog({ open, onOpenChange, projectId, task, allTasks = [], members = [] }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState(defaultForm);
  const [tagInput, setTagInput] = useState('');
  const [checklistInput, setChecklistInput] = useState('');

  useEffect(() => {
    if (task) {
      setForm({
        ...defaultForm,
        ...task,
        estimated_hours: task.estimated_hours || '',
        actual_hours: task.actual_hours || '',
        tags: task.tags || [],
        checklist: task.checklist || [],
        dependency_ids: task.dependency_ids || [],
      });
    } else {
      setForm({ ...defaultForm });
    }
  }, [task, open]);

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const payload = {
        ...data,
        project_id: projectId,
        estimated_hours: data.estimated_hours ? Number(data.estimated_hours) : undefined,
        actual_hours: data.actual_hours ? Number(data.actual_hours) : undefined,
      };
      if (task?.id) return base44.entities.Task.update(task.id, payload);
      return base44.entities.Task.create(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks', projectId] });
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
      onOpenChange(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.Task.delete(task.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks', projectId] });
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
      onOpenChange(false);
    },
  });

  const addTag = () => {
    if (tagInput.trim() && !form.tags.includes(tagInput.trim())) {
      setForm({ ...form, tags: [...form.tags, tagInput.trim()] });
      setTagInput('');
    }
  };

  const addChecklistItem = () => {
    if (checklistInput.trim()) {
      setForm({ ...form, checklist: [...form.checklist, { text: checklistInput.trim(), completed: false }] });
      setChecklistInput('');
    }
  };

  const toggleChecklistItem = (index) => {
    const newChecklist = [...form.checklist];
    newChecklist[index] = { ...newChecklist[index], completed: !newChecklist[index].completed };
    setForm({ ...form, checklist: newChecklist });
  };

  const removeChecklistItem = (index) => {
    setForm({ ...form, checklist: form.checklist.filter((_, i) => i !== index) });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-mono text-sm tracking-wider">
            {task?.id ? 'EDIT TASK' : 'NEW TASK'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-[10px] font-mono tracking-widest">TITLE *</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Task title" />
          </div>

          <div className="space-y-1.5">
            <Label className="text-[10px] font-mono tracking-widest">DESCRIPTION</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Details..." rows={2} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-mono tracking-widest">STATUS</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="backlog">Backlog</SelectItem>
                  <SelectItem value="todo">To Do</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[10px] font-mono tracking-widest">PRIORITY</Label>
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[10px] font-mono tracking-widest">ASSIGNEE</Label>
            {members.length > 0 ? (
              <Select value={form.assignee || "unassigned"} onValueChange={(v) => setForm({ ...form, assignee: v === "unassigned" ? "" : v })}>
                <SelectTrigger className="text-xs"><SelectValue placeholder="Select assignee" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="unassigned">Unassigned</SelectItem>
                  {members.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            ) : (
              <Input value={form.assignee} onChange={(e) => setForm({ ...form, assignee: e.target.value })} placeholder="email@example.com" />
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-mono tracking-widest">START DATE</Label>
              <Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[10px] font-mono tracking-widest">DUE DATE</Label>
              <Input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-mono tracking-widest">EST. HOURS</Label>
              <Input type="number" value={form.estimated_hours} onChange={(e) => setForm({ ...form, estimated_hours: e.target.value })} placeholder="0" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[10px] font-mono tracking-widest">ACTUAL HOURS</Label>
              <Input type="number" value={form.actual_hours} onChange={(e) => setForm({ ...form, actual_hours: e.target.value })} placeholder="0" />
            </div>
          </div>

          {/* Dependencies */}
          <div className="space-y-1.5">
            <Label className="text-[10px] font-mono tracking-widest">DEPENDS ON</Label>
            <Select value="" onValueChange={(v) => {
              if (v && !form.dependency_ids.includes(v)) {
                setForm({ ...form, dependency_ids: [...form.dependency_ids, v] });
              }
            }}>
              <SelectTrigger className="text-xs"><SelectValue placeholder="Add dependency..." /></SelectTrigger>
              <SelectContent>
                {allTasks.filter(t => t.id !== task?.id).map(t => (
                  <SelectItem key={t.id} value={t.id}>{t.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex flex-wrap gap-1">
              {form.dependency_ids.map(depId => {
                const dep = allTasks.find(t => t.id === depId);
                return (
                  <Badge key={depId} variant="secondary" className="text-[10px] gap-1">
                    {dep?.title || depId}
                    <button onClick={() => setForm({ ...form, dependency_ids: form.dependency_ids.filter(d => d !== depId) })}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                );
              })}
            </div>
          </div>

          {/* Recurring */}
          <div className="flex items-center justify-between py-2 border-t border-border">
            <Label className="text-[10px] font-mono tracking-widest">RECURRING TASK</Label>
            <Switch checked={form.is_recurring} onCheckedChange={(v) => setForm({ ...form, is_recurring: v })} />
          </div>
          {form.is_recurring && (
            <Select value={form.recurrence_pattern} onValueChange={(v) => setForm({ ...form, recurrence_pattern: v })}>
              <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="biweekly">Bi-weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          )}

          {/* Checklist */}
          <div className="space-y-1.5 border-t border-border pt-3">
            <Label className="text-[10px] font-mono tracking-widest">CHECKLIST / SUBTASKS</Label>
            <div className="flex gap-2">
              <Input value={checklistInput} onChange={(e) => setChecklistInput(e.target.value)} placeholder="Add item..." className="text-xs" onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addChecklistItem())} />
              <Button type="button" variant="outline" size="sm" onClick={addChecklistItem}><Plus className="w-3 h-3" /></Button>
            </div>
            <div className="space-y-1">
              {form.checklist.map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <input type="checkbox" checked={item.completed} onChange={() => toggleChecklistItem(i)} className="rounded" />
                  <span className={item.completed ? 'line-through text-muted-foreground' : ''}>{item.text}</span>
                  <button onClick={() => removeChecklistItem(i)} className="ml-auto text-muted-foreground hover:text-destructive">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-1.5">
            <Label className="text-[10px] font-mono tracking-widest">TAGS</Label>
            <div className="flex gap-2">
              <Input value={tagInput} onChange={(e) => setTagInput(e.target.value)} placeholder="Add tag..." className="text-xs" onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())} />
              <Button type="button" variant="outline" size="sm" onClick={addTag}><Plus className="w-3 h-3" /></Button>
            </div>
            <div className="flex flex-wrap gap-1">
              {form.tags.map(tag => (
                <Badge key={tag} variant="secondary" className="text-[10px] gap-1">
                  {tag}
                  <button onClick={() => setForm({ ...form, tags: form.tags.filter(t => t !== tag) })}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button
              onClick={() => saveMutation.mutate(form)}
              disabled={!form.title || saveMutation.isPending}
              className="gap-2 font-mono text-[10px] tracking-wider"
            >
              <Save className="w-3 h-3" /> {saveMutation.isPending ? 'SAVING...' : 'SAVE'}
            </Button>
            {task?.id && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => deleteMutation.mutate()}
                disabled={deleteMutation.isPending}
                className="gap-1 font-mono text-[10px] tracking-wider"
              >
                <Trash2 className="w-3 h-3" /> DELETE
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}