import React, { useState, useMemo } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, subMonths, getDay } from 'date-fns';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { parseLocalDate } from '@/utils';

const priorityDot = {
  critical: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-amber-500',
  low: 'bg-blue-500',
};

export default function ProjectCalendar({ tasks, projectId }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const startPadding = getDay(monthStart);

  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const tasksByDate = useMemo(() => {
    const map = {};
    tasks.forEach(task => {
      if (task.due_date) {
        const key = format(parseLocalDate(task.due_date), 'yyyy-MM-dd');
        if (!map[key]) map[key] = [];
        map[key].push(task);
      }
      if (task.start_date) {
        const key = format(parseLocalDate(task.start_date), 'yyyy-MM-dd');
        if (!map[key]) map[key] = [];
        if (!map[key].find(t => t.id === task.id)) {
          map[key].push(task);
        }
      }
    });
    return map;
  }, [tasks]);

  const today = new Date();

  return (
    <div className="bg-card border border-border rounded">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <span className="font-mono text-sm tracking-wider">{format(currentMonth, 'MMMM yyyy').toUpperCase()}</span>
        <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 border-b border-border">
        {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map(day => (
          <div key={day} className="text-center py-2 text-[10px] font-mono tracking-widest text-muted-foreground">
            {day}
          </div>
        ))}
      </div>

      {/* Days grid */}
      <div className="grid grid-cols-7">
        {/* Padding for start of month */}
        {Array.from({ length: startPadding }).map((_, i) => (
          <div key={`pad-${i}`} className="min-h-[80px] border-b border-r border-border/50 bg-muted/20" />
        ))}
        {days.map((day) => {
          const key = format(day, 'yyyy-MM-dd');
          const dayTasks = tasksByDate[key] || [];
          const isToday = isSameDay(day, today);

          return (
            <div
              key={key}
              className={cn(
                "min-h-[80px] border-b border-r border-border/50 p-1",
                isToday && "bg-primary/5"
              )}
            >
              <div className={cn(
                "text-xs font-mono w-6 h-6 flex items-center justify-center rounded-full mb-1",
                isToday && "bg-primary text-primary-foreground"
              )}>
                {format(day, 'd')}
              </div>
              <div className="space-y-0.5">
                {dayTasks.slice(0, 3).map(task => (
                  <Link
                    key={task.id}
                    to={`/projects/${projectId}/tasks/${task.id}`}
                    className="flex items-center gap-1 px-1 py-0.5 rounded hover:bg-muted/50 transition-colors"
                  >
                    <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", priorityDot[task.priority] || 'bg-slate-400')} />
                    <span className="text-[9px] truncate">{task.title}</span>
                  </Link>
                ))}
                {dayTasks.length > 3 && (
                  <span className="text-[9px] text-muted-foreground px-1">+{dayTasks.length - 3} more</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}