import React from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, FolderKanban } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { parseLocalDate } from '@/utils';

const columns = [
  { id: 'backlog', label: 'BACKLOG', color: 'border-t-slate-400' },
  { id: 'todo', label: 'TO DO', color: 'border-t-blue-400' },
  { id: 'in_progress', label: 'IN PROGRESS', color: 'border-t-amber-400' },
  { id: 'review', label: 'REVIEW', color: 'border-t-purple-400' },
  { id: 'completed', label: 'DONE', color: 'border-t-emerald-400' },
];

const priorityDot = {
  critical: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-amber-500',
  low: 'bg-blue-500',
};

export default function AllTasksKanban({ tasks, projectMap }) {
  const queryClient = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Task.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
    },
  });

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const { draggableId, destination } = result;
    updateMutation.mutate({ id: draggableId, data: { status: destination.droppableId, kanban_order: destination.index } });
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-3 overflow-x-auto pb-4 min-h-[400px]">
        {columns.map((col) => {
          const colTasks = tasks
            .filter(t => t.status === col.id)
            .sort((a, b) => (a.kanban_order || 0) - (b.kanban_order || 0));

          return (
            <div key={col.id} className="flex-shrink-0 w-64">
              <div className={cn("border-t-2 rounded bg-muted/30 h-full", col.color)}>
                <div className="flex items-center justify-between px-3 py-2">
                  <span className="text-[10px] font-mono tracking-widest text-muted-foreground">{col.label}</span>
                  <span className="text-[10px] font-mono text-muted-foreground bg-muted rounded-full px-2 py-0.5">{colTasks.length}</span>
                </div>
                <Droppable droppableId={col.id}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={cn("px-2 pb-2 space-y-2 min-h-[100px] transition-colors", snapshot.isDraggingOver && "bg-primary/5")}
                    >
                      {colTasks.map((task, index) => {
                        const project = projectMap[task.project_id];
                        return (
                          <Draggable key={task.id} draggableId={task.id} index={index}>
                            {(provided, snapshot) => (
                              <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
                                <Link
                                  to={`/projects/${task.project_id}/tasks/${task.id}`}
                                  className={cn(
                                    "block bg-card border border-border rounded p-3 hover:border-primary/30 transition-all",
                                    snapshot.isDragging && "shadow-lg rotate-1"
                                  )}
                                >
                                  <div className="flex items-start gap-2 mb-2">
                                    <div className={cn("w-2 h-2 rounded-full mt-1 flex-shrink-0", priorityDot[task.priority] || 'bg-slate-400')} />
                                    <p className="text-xs font-medium leading-tight">{task.title}</p>
                                  </div>
                                  <div className="flex items-center gap-2 flex-wrap">
                                    {project && (
                                      <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                        <FolderKanban className="w-3 h-3" /> {project.name}
                                      </span>
                                    )}
                                    {task.due_date && (
                                      <span className={cn(
                                        "text-[10px] flex items-center gap-1",
                                        parseLocalDate(task.due_date) < new Date() && task.status !== 'completed' ? "text-red-400" : "text-muted-foreground"
                                      )}>
                                        <Calendar className="w-3 h-3" /> {format(parseLocalDate(task.due_date), 'MMM d')}
                                      </span>
                                    )}
                                    {task.assignee && (
                                      <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                        <User className="w-3 h-3" />
                                      </span>
                                    )}
                                  </div>
                                </Link>
                              </div>
                            )}
                          </Draggable>
                        );
                      })}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </div>
            </div>
          );
        })}
      </div>
    </DragDropContext>
  );
}