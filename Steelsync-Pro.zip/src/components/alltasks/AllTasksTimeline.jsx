import React, { useMemo } from 'react';
import { format, differenceInDays, addDays, startOfWeek, endOfWeek } from 'date-fns';
import { cn } from '@/lib/utils';
import { parseLocalDate } from '@/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';

const priorityColors = {
  critical: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-amber-500',
  low: 'bg-blue-500',
};

const statusColors = {
  backlog: 'opacity-40',
  todo: 'opacity-60',
  in_progress: '',
  review: '',
  completed: 'opacity-70',
};

export default function AllTasksTimeline({ tasks, projectMap }) {
  const tasksWithDates = tasks.filter(t => t.start_date || t.due_date);

  const { minDate, totalDays, weeks } = useMemo(() => {
    if (tasksWithDates.length === 0) {
      const today = new Date();
      return { minDate: today, totalDays: 30, weeks: [] };
    }
    const dates = tasksWithDates.flatMap(t => [
      t.start_date ? parseLocalDate(t.start_date) : null,
      t.due_date ? parseLocalDate(t.due_date) : null,
    ]).filter(Boolean);
    const min = new Date(Math.min(...dates));
    const max = new Date(Math.max(...dates));
    const paddedMin = addDays(startOfWeek(min), -7);
    const paddedMax = addDays(endOfWeek(max), 7);
    const total = differenceInDays(paddedMax, paddedMin) + 1;
    const w = [];
    let current = paddedMin;
    while (current < paddedMax) { w.push(current); current = addDays(current, 7); }
    return { minDate: paddedMin, totalDays: total, weeks: w };
  }, [tasksWithDates]);

  if (tasksWithDates.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground text-sm">
        Add start/due dates to tasks to see the timeline
      </div>
    );
  }

  const dayWidth = 32;
  const today = new Date();
  const todayOffset = differenceInDays(today, minDate);

  return (
    <ScrollArea className="w-full">
      <div className="min-w-fit">
        <div className="flex border-b border-border sticky top-0 bg-card z-10">
          <div className="w-56 flex-shrink-0 p-2 border-r border-border">
            <span className="text-[10px] font-mono tracking-widest text-muted-foreground">TASK</span>
          </div>
          <div className="flex" style={{ width: totalDays * dayWidth }}>
            {weeks.map((week, i) => (
              <div key={i} className="border-r border-border/50 text-center" style={{ width: 7 * dayWidth }}>
                <span className="text-[10px] font-mono text-muted-foreground">{format(week, 'MMM d')}</span>
              </div>
            ))}
          </div>
        </div>
        {tasksWithDates.map((task) => {
          const start = task.start_date ? parseLocalDate(task.start_date) : parseLocalDate(task.due_date);
          const end = task.due_date ? parseLocalDate(task.due_date) : parseLocalDate(task.start_date);
          const startOffset = differenceInDays(start, minDate);
          const duration = Math.max(differenceInDays(end, start) + 1, 1);
          const project = projectMap[task.project_id];

          return (
            <div key={task.id} className="flex border-b border-border/50 hover:bg-muted/30 transition-colors">
              <div className="w-56 flex-shrink-0 p-2 border-r border-border flex flex-col justify-center min-h-[36px]">
                <div className="flex items-center gap-2">
                  <div className={cn("w-2 h-2 rounded-full flex-shrink-0", priorityColors[task.priority] || 'bg-slate-400')} />
                  <span className="text-xs truncate">{task.title}</span>
                </div>
                {project && (
                  <span className="text-[9px] text-muted-foreground ml-4 truncate">{project.name}</span>
                )}
              </div>
              <div className="relative" style={{ width: totalDays * dayWidth, height: 42 }}>
                {todayOffset >= 0 && todayOffset <= totalDays && (
                  <div className="absolute top-0 bottom-0 w-px bg-primary/40 z-10" style={{ left: todayOffset * dayWidth }} />
                )}
                <div
                  className={cn(
                    "absolute top-2 h-5 rounded-sm flex items-center px-1.5",
                    priorityColors[task.priority] || 'bg-slate-500',
                    statusColors[task.status] || ''
                  )}
                  style={{ left: startOffset * dayWidth, width: Math.max(duration * dayWidth, 24) }}
                >
                  <span className="text-[9px] text-white font-medium truncate">
                    {task.status === 'completed' ? '✓' : ''} {format(start, 'M/d')} – {format(end, 'M/d')}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}