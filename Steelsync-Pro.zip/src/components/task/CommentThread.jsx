import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Paperclip } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function CommentThread({ comments, taskId }) {
  const [content, setContent] = useState('');
  const queryClient = useQueryClient();

  const addCommentMutation = useMutation({
    mutationFn: async (text) => {
      const user = await base44.auth.me();
      return base44.entities.Comment.create({
        task_id: taskId,
        content: text,
        author_name: user.full_name || user.email,
        author_email: user.email,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['task-comments', taskId] });
      setContent('');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    addCommentMutation.mutate(content.trim());
  };

  return (
    <div className="space-y-3">
      <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground uppercase">
        Comments ({comments.length})
      </h3>

      {/* Comment list */}
      <div className="space-y-3">
        {comments.map((comment) => (
          <div key={comment.id} className="bg-muted/30 rounded p-3">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-[10px] font-bold text-primary">
                  {(comment.author_name || comment.author_email || '?')[0].toUpperCase()}
                </span>
              </div>
              <span className="text-xs font-medium">{comment.author_name || comment.author_email}</span>
              <span className="text-[10px] text-muted-foreground">
                {formatDistanceToNow(new Date(comment.created_date), { addSuffix: true })}
              </span>
            </div>
            <p className="text-sm text-foreground/80 pl-8 whitespace-pre-wrap">{comment.content}</p>
          </div>
        ))}
      </div>

      {/* New comment */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Add a comment..."
          rows={2}
          className="text-sm flex-1"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
              handleSubmit(e);
            }
          }}
        />
        <Button
          type="submit"
          size="icon"
          disabled={!content.trim() || addCommentMutation.isPending}
          className="flex-shrink-0 self-end"
        >
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </div>
  );
}