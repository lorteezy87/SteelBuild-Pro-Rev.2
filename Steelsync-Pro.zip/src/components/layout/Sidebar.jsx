import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import {
  LayoutDashboard, FolderKanban, Plus, ChevronLeft, ChevronRight,
  Bell, LogOut, Settings, HardHat, Menu, X, ListChecks,
  Inbox, Calendar, CalendarDays, Bot, BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

const PROJECT_COLORS = [
  'bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-purple-500',
  'bg-rose-500', 'bg-cyan-500', 'bg-orange-500', 'bg-teal-500',
  'bg-indigo-500', 'bg-pink-500', 'bg-lime-500', 'bg-sky-500',
  'bg-violet-500', 'bg-fuchsia-500', 'bg-yellow-500'
];

export default function Sidebar({ collapsed, setCollapsed }) {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const { data: projects = [] } = useQuery({
    queryKey: ['projects-sidebar'],
    queryFn: () => base44.entities.Project.list('-created_date', 20),
    initialData: [],
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications-unread'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Notification.filter({ user_email: user.email, is_read: false }, '-created_date', 10);
    },
    initialData: [],
  });

  const unreadCount = notifications.length;

  const navItems = [
    { icon: LayoutDashboard, label: 'Command Center', path: '/' },
    { icon: Inbox, label: 'Inbox', path: '/inbox' },
    { icon: Calendar, label: 'Planner', path: '/planner' },
    { icon: ListChecks, label: 'Tasks', path: '/tasks' },
    { icon: FolderKanban, label: 'Projects', path: '/projects' },
    { icon: CalendarDays, label: 'Meetings', path: '/meetings' },
    { icon: Bot, label: 'AI Workforce', path: '/ai-workforce' },
    { icon: BarChart3, label: 'Reports', path: '/reports' },
    { icon: Bell, label: 'Notifications', path: '/notifications', badge: unreadCount },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  const isActive = (path) => location.pathname === path;

  const sidebarContent = (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-sidebar-border">
        <div className="w-8 h-8 bg-sidebar-primary rounded flex items-center justify-center flex-shrink-0">
          <HardHat className="w-5 h-5 text-sidebar-primary-foreground" />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <h1 className="font-mono font-bold text-sm tracking-wider text-sidebar-primary-foreground truncate">
              BUILDBOARD
            </h1>
            <p className="text-[10px] font-mono text-sidebar-foreground/60 tracking-widest">
              EXECUTION PLATFORM
            </p>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="p-2 space-y-1">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            onClick={() => setMobileOpen(false)}
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors",
              isActive(item.path)
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-sidebar-foreground hover:bg-sidebar-accent/50"
            )}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            {!collapsed && <span className="truncate">{item.label}</span>}
            {!collapsed && item.badge > 0 && (
              <Badge variant="destructive" className="ml-auto text-[10px] h-5 px-1.5">
                {item.badge}
              </Badge>
            )}
          </Link>
        ))}
      </nav>

      {/* Projects List */}
      {!collapsed && (
        <>
          <div className="flex items-center justify-between px-4 py-2 mt-2">
            <span className="text-[10px] font-mono tracking-widest text-sidebar-foreground/50 uppercase">
              Projects
            </span>
            <Link to="/projects/new" onClick={() => setMobileOpen(false)}>
              <Button variant="ghost" size="icon" className="h-5 w-5 text-sidebar-foreground/50 hover:text-sidebar-foreground">
                <Plus className="w-3 h-3" />
              </Button>
            </Link>
          </div>
          <ScrollArea className="flex-1 px-2">
            <div className="space-y-0.5 pb-4">
              {projects.map((project, idx) => (
                <Link
                  key={project.id}
                  to={`/projects/${project.id}`}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded text-sm transition-colors",
                    location.pathname === `/projects/${project.id}`
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  )}
                >
                  <div className={cn("w-2 h-2 rounded-full flex-shrink-0", PROJECT_COLORS[idx % PROJECT_COLORS.length])} />
                  <span className="truncate text-xs">{project.name}</span>
                </Link>
              ))}
            </div>
          </ScrollArea>
        </>
      )}

      {/* Footer */}
      <div className="p-2 border-t border-sidebar-border mt-auto">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="hidden lg:flex items-center gap-3 px-3 py-2 rounded text-sm text-sidebar-foreground/60 hover:bg-sidebar-accent/50 w-full transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          {!collapsed && <span>Collapse</span>}
        </button>
        <button
          onClick={() => base44.auth.logout()}
          className="flex items-center gap-3 px-3 py-2 rounded text-sm text-sidebar-foreground/60 hover:bg-sidebar-accent/50 w-full transition-colors"
        >
          <LogOut className="w-4 h-4 flex-shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-3 left-3 z-50 p-2 bg-sidebar rounded text-sidebar-foreground"
      >
        {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-40" onClick={() => setMobileOpen(false)} />
      )}

      {/* Mobile sidebar */}
      <div className={cn(
        "lg:hidden fixed inset-y-0 left-0 z-40 w-64 transform transition-transform",
        mobileOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {sidebarContent}
      </div>

      {/* Desktop sidebar */}
      <div className={cn(
        "hidden lg:flex flex-col flex-shrink-0 transition-all duration-200",
        collapsed ? "w-16" : "w-60"
      )}>
        {sidebarContent}
      </div>
    </>
  );
}