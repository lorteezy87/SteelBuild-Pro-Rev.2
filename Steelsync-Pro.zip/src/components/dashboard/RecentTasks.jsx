import React from 'react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { parseLocalDate } from '@/utils';

const priorityConfig = {
  critical: { label: 'CRITICAL', class: 'bg-red-500/10 text-red-400 border-red-500/20' },
  high: { label: 'HIGH', class: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  medium: { label: 'MED', class: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  low: { label: 'LOW', class: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
};

export default function RecentTasks({ tasks, projects }) {
  const projectMap = {};
  projects.forEach(p => { projectMap[p.id] = p; });

  const recentTasks = tasks
    .filter(t => t.status !== 'completed')
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 8);

  return (
    <div className="bg-card border border-border rounded">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-mono text-xs tracking-widest text-muted-foreground uppercase">Recent Tasks</h3>
        <Link to="/projects" className="text-xs text-primary hover:underline flex items-center gap-1">
          View all <ArrowRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="divide-y divide-border">
        {recentTasks.length === 0 && (
          <div className="p-8 text-center text-muted-foreground text-sm">No active tasks</div>
        )}
        {recentTasks.map((task) => {
          const project = projectMap[task.project_id];
          const prio = priorityConfig[task.priority] || priorityConfig.medium;
          return (
            <Link
              key={task.id}
              to={`/projects/${task.project_id}/tasks/${task.id}`}
              className="flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{task.title}</p>
                <div className="flex items-center gap-2 mt-1">
                  {project && (
                    <span className="text-[10px] font-mono text-muted-foreground truncate">
                      {project.name}
                    </span>
                  )}
                  {task.due_date && (
                    <span className="text-[10px] flex items-center gap-1 text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      {format(parseLocalDate(task.due_date), 'MMM d')}
                    </span>
                  )}
                </div>
              </div>
              <Badge variant="outline" className={`text-[10px] font-mono ${prio.class}`}>
                {prio.label}
              </Badge>
            </Link>
          );
        })}
      </div>
    </div>
  );
}