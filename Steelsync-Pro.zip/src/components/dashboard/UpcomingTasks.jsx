import React from 'react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { format, differenceInHours } from 'date-fns';
import { Clock, AlertTriangle, Calendar } from 'lucide-react';
import { parseLocalDate } from '@/utils';
import { cn } from '@/lib/utils';

const priorityConfig = {
  critical: { label: 'CRIT', class: 'bg-red-500/10 text-red-400 border-red-500/20' },
  high: { label: 'HIGH', class: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  medium: { label: 'MED', class: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  low: { label: 'LOW', class: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
};

export default function UpcomingTasks({ tasks, projects, hoursAhead, label, icon: Icon }) {
  const projectMap = {};
  projects.forEach(p => { projectMap[p.id] = p; });

  const now = new Date();
  const upcoming = tasks
    .filter(t => {
      if (t.status === 'completed' || !t.due_date) return false;
      const due = parseLocalDate(t.due_date);
      // Set to end of day for the due date
      due.setHours(23, 59, 59, 999);
      const hoursLeft = differenceInHours(due, now);
      return hoursLeft >= 0 && hoursLeft <= hoursAhead;
    })
    .sort((a, b) => parseLocalDate(a.due_date) - parseLocalDate(b.due_date));

  return (
    <div className="bg-card border border-border rounded">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-mono text-xs tracking-widest text-muted-foreground uppercase flex items-center gap-2">
          <Icon className="w-3.5 h-3.5" /> {label}
        </h3>
        <span className="text-[10px] font-mono text-muted-foreground">
          {upcoming.length} {upcoming.length === 1 ? 'TASK' : 'TASKS'}
        </span>
      </div>
      <div className="divide-y divide-border">
        {upcoming.length === 0 ? (
          <div className="p-6 text-center text-muted-foreground text-sm">
            No tasks due in this window
          </div>
        ) : (
          upcoming.map((task) => {
            const project = projectMap[task.project_id];
            const prio = priorityConfig[task.priority] || priorityConfig.medium;
            const due = parseLocalDate(task.due_date);
            const hoursLeft = differenceInHours(due, now);
            const isUrgent = hoursLeft <= 24;

            return (
              <Link
                key={task.id}
                to={`/projects/${task.project_id}/tasks/${task.id}`}
                className="flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors"
              >
                <div className={cn(
                  "w-1 h-8 rounded-full flex-shrink-0",
                  isUrgent ? "bg-red-500" : "bg-amber-500"
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{task.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {project && (
                      <span className="text-[10px] font-mono text-muted-foreground truncate">
                        {project.name}
                      </span>
                    )}
                    <span className={cn(
                      "text-[10px] flex items-center gap-1",
                      isUrgent ? "text-red-400" : "text-amber-400"
                    )}>
                      <Calendar className="w-3 h-3" />
                      {format(due, 'MMM d')}
                    </span>
                    {task.assignee && (
                      <span className="text-[10px] text-muted-foreground truncate">
                        · {task.assignee}
                      </span>
                    )}
                  </div>
                </div>
                <Badge variant="outline" className={`text-[10px] font-mono flex-shrink-0 ${prio.class}`}>
                  {prio.label}
                </Badge>
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
}