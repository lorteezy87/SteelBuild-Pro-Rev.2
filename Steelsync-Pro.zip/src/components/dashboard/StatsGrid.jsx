import React from 'react';
import { FolderKanban, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';
import { parseLocalDate } from '@/utils';

export default function StatsGrid({ projects, tasks }) {
  const activeProjects = projects.filter(p => p.status === 'active').length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const overdueTasks = tasks.filter(t => t.due_date && parseLocalDate(t.due_date) < new Date() && t.status !== 'completed').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress').length;

  const stats = [
    { label: 'ACTIVE PROJECTS', value: activeProjects, icon: FolderKanban, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'IN PROGRESS', value: inProgressTasks, icon: Clock, color: 'text-amber-400', bg: 'bg-amber-500/10' },
    { label: 'COMPLETED', value: completedTasks, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'OVERDUE', value: overdueTasks, icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10' },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {stats.map((stat) => (
        <div key={stat.label} className="bg-card border border-border rounded p-4">
          <div className="flex items-center justify-between mb-3">
            <div className={`p-2 rounded ${stat.bg}`}>
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono tracking-tight">{stat.value}</p>
          <p className="text-[10px] font-mono tracking-widest text-muted-foreground mt-1">{stat.label}</p>
        </div>
      ))}
    </div>
  );
}