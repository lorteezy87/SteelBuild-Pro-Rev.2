import React from 'react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowRight, MapPin, Users } from 'lucide-react';

const statusColors = {
  planning: 'bg-slate-500/10 text-slate-400',
  active: 'bg-emerald-500/10 text-emerald-400',
  on_hold: 'bg-amber-500/10 text-amber-400',
  completed: 'bg-blue-500/10 text-blue-400',
  archived: 'bg-muted text-muted-foreground',
};

export default function ProjectsOverview({ projects, tasks }) {
  const activeProjects = projects
    .filter(p => p.status !== 'archived')
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 6);

  return (
    <div className="bg-card border border-border rounded">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-mono text-xs tracking-widest text-muted-foreground uppercase">Projects</h3>
        <Link to="/projects" className="text-xs text-primary hover:underline flex items-center gap-1">
          All projects <ArrowRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="divide-y divide-border">
        {activeProjects.length === 0 && (
          <div className="p-8 text-center text-muted-foreground text-sm">No projects yet</div>
        )}
        {activeProjects.map((project) => {
          const projectTasks = tasks.filter(t => t.project_id === project.id);
          const completedCount = projectTasks.filter(t => t.status === 'completed').length;
          const progress = projectTasks.length > 0 ? Math.round((completedCount / projectTasks.length) * 100) : 0;

          return (
            <Link
              key={project.id}
              to={`/projects/${project.id}`}
              className="block p-3 hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{project.name}</p>
                  <div className="flex items-center gap-3 mt-1">
                    {project.location && (
                      <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {project.location}
                      </span>
                    )}
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Users className="w-3 h-3" /> {project.members?.length || 0}
                    </span>
                  </div>
                </div>
                <Badge variant="outline" className={`text-[10px] font-mono ${statusColors[project.status] || ''}`}>
                  {project.status?.replace('_', ' ').toUpperCase()}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Progress value={progress} className="h-1 flex-1" />
                <span className="text-[10px] font-mono text-muted-foreground w-8 text-right">{progress}%</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}