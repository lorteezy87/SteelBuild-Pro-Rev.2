import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Send, Loader2, Plus, Trash2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import MessageBubble from './MessageBubble';

export default function AgentChat({ agentName, agentDisplayName, onBack }) {
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);

  // Load conversations
  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const convos = await base44.agents.listConversations({ agent_name: agentName });
        if (!cancelled) {
          const list = Array.isArray(convos) ? convos : [];
          setConversations(list);
        }
      } catch (e) {
        console.error('Failed to load conversations:', e);
        if (!cancelled) {
          setConversations([]);
          setError(e.message || 'Failed to load');
        }
      }
      if (!cancelled) setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [agentName]);

  // Subscribe to active conversation
  useEffect(() => {
    if (!activeConversation?.id) return;
    const unsubscribe = base44.agents.subscribeToConversation(activeConversation.id, (data) => {
      setMessages(data.messages || []);
    });
    return () => unsubscribe();
  }, [activeConversation?.id]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startNewConversation = async () => {
    setCreating(true);
    try {
      const convo = await base44.agents.createConversation({
        agent_name: agentName,
        metadata: { name: `Chat ${new Date().toLocaleDateString()}` },
      });
      setConversations(prev => [convo, ...prev]);
      setActiveConversation(convo);
      setMessages(convo.messages || []);
    } catch (e) {
      console.error('Failed to create conversation:', e);
    }
    setCreating(false);
  };

  const openConversation = async (convo) => {
    const full = await base44.agents.getConversation(convo.id);
    setActiveConversation(full);
    setMessages(full.messages || []);
  };

  const sendMessage = async () => {
    if (!input.trim() || sending) return;
    const text = input.trim();
    setInput('');
    setSending(true);
    await base44.agents.addMessage(activeConversation, { role: 'user', content: text });
    setSending(false);
  };

  // Conversation list view
  if (!activeConversation) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center gap-3 p-4 border-b border-border">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <p className="text-xs font-mono font-bold tracking-wider">{agentDisplayName}</p>
            <p className="text-[10px] text-muted-foreground font-mono">CONVERSATIONS</p>
          </div>
          <Button size="sm" className="h-7 gap-1.5 font-mono text-[10px] tracking-wider" onClick={startNewConversation} disabled={creating}>
            {creating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />} NEW CHAT
          </Button>
        </div>
        <ScrollArea className="flex-1">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : error ? (
            <div className="text-center py-12 px-4">
              <p className="text-sm text-destructive mb-1">Could not load conversations</p>
              <p className="text-[10px] text-muted-foreground font-mono mb-3">{error}</p>
              <Button size="sm" variant="outline" className="font-mono text-[10px] tracking-wider" onClick={() => { setError(null); setLoading(true); base44.agents.listConversations({ agent_name: agentName }).then(c => { setConversations(Array.isArray(c) ? c : []); setLoading(false); }).catch(() => { setError('Retry failed'); setLoading(false); }); }}>
                RETRY
              </Button>
            </div>
          ) : conversations.length === 0 ? (
            <div className="text-center py-12 px-4">
              <p className="text-sm text-muted-foreground mb-3">No conversations yet</p>
              <Button size="sm" className="gap-1.5 font-mono text-[10px] tracking-wider" onClick={startNewConversation} disabled={creating}>
                {creating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />} START FIRST CHAT
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {conversations.map(convo => (
                <button
                  key={convo.id}
                  onClick={() => openConversation(convo)}
                  className="w-full text-left px-4 py-3 hover:bg-muted/30 transition-colors"
                >
                  <p className="text-xs font-medium truncate">{convo.metadata?.name || 'Untitled'}</p>
                  <p className="text-[10px] text-muted-foreground font-mono mt-0.5">
                    {new Date(convo.updated_date || convo.created_date).toLocaleDateString()}
                  </p>
                </button>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>
    );
  }

  // Chat view
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 p-4 border-b border-border">
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setActiveConversation(null)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <p className="text-xs font-mono font-bold tracking-wider">{agentDisplayName}</p>
          <p className="text-[10px] text-muted-foreground font-mono">
            {activeConversation.metadata?.name || 'CHAT'}
          </p>
        </div>
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">Send a message to start the conversation</p>
            </div>
          )}
          {messages.map((msg, i) => (
            <MessageBubble key={i} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-border">
        <form
          onSubmit={(e) => { e.preventDefault(); sendMessage(); }}
          className="flex gap-2"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 text-sm"
            disabled={sending}
          />
          <Button type="submit" size="icon" className="h-9 w-9" disabled={!input.trim() || sending}>
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      </div>
    </div>
  );
}