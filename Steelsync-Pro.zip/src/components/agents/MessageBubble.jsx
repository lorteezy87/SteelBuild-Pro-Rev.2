import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Button } from "@/components/ui/button";
import { Copy, Zap, CheckCircle2, AlertCircle, Loader2, ChevronRight, Clock } from 'lucide-react';
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const FunctionDisplay = ({ toolCall }) => {
    const [expanded, setExpanded] = useState(false);
    const name = toolCall?.name || 'Function';
    const status = toolCall?.status || 'pending';
    const results = toolCall?.results;

    const parsedResults = (() => {
        if (!results) return null;
        try { return typeof results === 'string' ? JSON.parse(results) : results; } catch { return results; }
    })();

    const isError = results && (
        (typeof results === 'string' && /error|failed/i.test(results)) ||
        (parsedResults?.success === false)
    );

    const statusConfig = {
        pending: { icon: Clock, color: 'text-muted-foreground', text: 'Pending' },
        running: { icon: Loader2, color: 'text-muted-foreground', text: 'Running...', spin: true },
        in_progress: { icon: Loader2, color: 'text-muted-foreground', text: 'Running...', spin: true },
        completed: isError
            ? { icon: AlertCircle, color: 'text-red-400', text: 'Failed' }
            : { icon: CheckCircle2, color: 'text-emerald-400', text: 'Success' },
        success: { icon: CheckCircle2, color: 'text-emerald-400', text: 'Success' },
        failed: { icon: AlertCircle, color: 'text-red-400', text: 'Failed' },
        error: { icon: AlertCircle, color: 'text-red-400', text: 'Failed' }
    }[status] || { icon: Zap, color: 'text-muted-foreground', text: '' };

    const Icon = statusConfig.icon;
    const formattedName = name.split('.').reverse().join(' ').toLowerCase();

    return (
        <div className="mt-2 text-xs">
            <button
                onClick={() => setExpanded(!expanded)}
                className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded border transition-all",
                    "hover:bg-muted/50",
                    expanded ? "bg-muted/50 border-border" : "bg-card border-border"
                )}
            >
                <Icon className={cn("h-3 w-3", statusConfig.color, statusConfig.spin && "animate-spin")} />
                <span className="text-foreground font-mono text-[10px] tracking-wider">{formattedName}</span>
                {statusConfig.text && (
                    <span className={cn("text-muted-foreground", isError && "text-red-400")}>· {statusConfig.text}</span>
                )}
                {!statusConfig.spin && (toolCall.arguments_string || results) && (
                    <ChevronRight className={cn("h-3 w-3 text-muted-foreground transition-transform ml-auto", expanded && "rotate-90")} />
                )}
            </button>
            {expanded && !statusConfig.spin && (
                <div className="mt-1.5 ml-3 pl-3 border-l-2 border-border space-y-2">
                    {toolCall.arguments_string && (
                        <div>
                            <div className="text-[10px] font-mono text-muted-foreground mb-1">PARAMS:</div>
                            <pre className="bg-muted rounded p-2 text-[10px] text-muted-foreground whitespace-pre-wrap font-mono">
                                {(() => { try { return JSON.stringify(JSON.parse(toolCall.arguments_string), null, 2); } catch { return toolCall.arguments_string; } })()}
                            </pre>
                        </div>
                    )}
                    {parsedResults && (
                        <div>
                            <div className="text-[10px] font-mono text-muted-foreground mb-1">RESULT:</div>
                            <pre className="bg-muted rounded p-2 text-[10px] text-muted-foreground whitespace-pre-wrap max-h-48 overflow-auto font-mono">
                                {typeof parsedResults === 'object' ? JSON.stringify(parsedResults, null, 2) : parsedResults}
                            </pre>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default function MessageBubble({ message }) {
    const isUser = message.role === 'user';

    return (
        <div className={cn("flex gap-3", isUser ? "justify-end" : "justify-start")}>
            {!isUser && (
                <div className="h-6 w-6 rounded bg-primary/10 flex items-center justify-center mt-0.5 flex-shrink-0">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                </div>
            )}
            <div className={cn("max-w-[85%]", isUser && "flex flex-col items-end")}>
                {message.content && (
                    <div className={cn(
                        "rounded px-3 py-2",
                        isUser ? "bg-primary text-primary-foreground" : "bg-card border border-border"
                    )}>
                        {isUser ? (
                            <p className="text-sm leading-relaxed">{message.content}</p>
                        ) : (
                            <ReactMarkdown
                                className="text-sm prose prose-sm prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
                                components={{
                                    p: ({ children }) => <p className="my-1 leading-relaxed text-foreground">{children}</p>,
                                    ul: ({ children }) => <ul className="my-1 ml-4 list-disc text-foreground">{children}</ul>,
                                    ol: ({ children }) => <ol className="my-1 ml-4 list-decimal text-foreground">{children}</ol>,
                                    li: ({ children }) => <li className="my-0.5 text-foreground">{children}</li>,
                                    strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
                                    code: ({ inline, children }) => inline
                                        ? <code className="px-1 py-0.5 rounded bg-muted text-xs font-mono">{children}</code>
                                        : <pre className="bg-muted rounded p-2 my-2 overflow-x-auto"><code className="text-xs font-mono">{children}</code></pre>,
                                    a: ({ children, ...props }) => <a {...props} target="_blank" rel="noopener noreferrer" className="text-primary underline">{children}</a>,
                                }}
                            >
                                {message.content}
                            </ReactMarkdown>
                        )}
                    </div>
                )}
                {message.tool_calls?.length > 0 && (
                    <div className="space-y-1">
                        {message.tool_calls.map((toolCall, idx) => (
                            <FunctionDisplay key={idx} toolCall={toolCall} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}