import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Plus, CalendarDays, MapPin, Users, Clock, Repeat, FolderKanban, Pencil, Trash2 } from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { format, isToday, isFuture, isPast } from 'date-fns';
import { Switch } from '@/components/ui/switch';
import { parseLocalDate } from '@/utils';
import { cn } from '@/lib/utils';

const statusConfig = {
  scheduled: { label: 'SCHEDULED', class: 'bg-blue-500/10 text-blue-400' },
  in_progress: { label: 'IN PROGRESS', class: 'bg-amber-500/10 text-amber-400' },
  completed: { label: 'COMPLETED', class: 'bg-emerald-500/10 text-emerald-400' },
  cancelled: { label: 'CANCELLED', class: 'bg-slate-500/10 text-slate-400' },
};

export default function Meetings() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [filter, setFilter] = useState('upcoming');

  const defaultForm = { title: '', date: format(new Date(), 'yyyy-MM-dd'), start_time: '10:00', end_time: '11:00', location: '', description: '', project_id: '', is_recurring: false, recurrence_pattern: 'weekly', recurrence_end_date: '' };
  const [form, setForm] = useState(defaultForm);

  const { data: meetings = [], isLoading } = useQuery({
    queryKey: ['meetings'],
    queryFn: () => base44.entities.Meeting.list('-date', 200),
    initialData: [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects-meetings'],
    queryFn: () => base44.entities.Project.list('-created_date', 200),
    initialData: [],
  });

  const projectMap = {};
  projects.forEach(p => { projectMap[p.id] = p; });

  const saveMutation = useMutation({
    mutationFn: (data) => editingMeeting
      ? base44.entities.Meeting.update(editingMeeting.id, data)
      : base44.entities.Meeting.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['meetings'] }); closeDialog(); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Meeting.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['meetings'] }); setDeleteTarget(null); },
  });

  const openCreate = () => { setEditingMeeting(null); setForm(defaultForm); setDialogOpen(true); };
  const openEdit = (m) => {
    setEditingMeeting(m);
    setForm({ title: m.title || '', date: m.date || '', start_time: m.start_time || '10:00', end_time: m.end_time || '11:00', location: m.location || '', description: m.description || '', project_id: m.project_id || '', is_recurring: m.is_recurring || false, recurrence_pattern: m.recurrence_pattern || 'weekly', recurrence_end_date: m.recurrence_end_date || '' });
    setDialogOpen(true);
  };
  const closeDialog = () => { setDialogOpen(false); setEditingMeeting(null); setForm(defaultForm); };

  const filtered = meetings.filter(m => {
    const d = parseLocalDate(m.date);
    if (filter === 'today') return isToday(d);
    if (filter === 'upcoming') return isFuture(d) || isToday(d);
    if (filter === 'past') return isPast(d) && !isToday(d);
    return true;
  });

  const todayCount = meetings.filter(m => isToday(parseLocalDate(m.date))).length;

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl lg:text-2xl font-bold tracking-tight font-mono">MEETINGS</h1>
          <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
            {todayCount} TODAY · {meetings.length} TOTAL
          </p>
        </div>
        <Button size="sm" className="gap-1.5 font-mono text-[10px] tracking-wider" onClick={openCreate}>
          <Plus className="w-3 h-3" /> SCHEDULE
        </Button>
      </div>

      <div className="flex gap-2">
        {['today', 'upcoming', 'past', 'all'].map(f => (
          <Button key={f} variant={filter === f ? 'secondary' : 'ghost'} size="sm" className="h-7 text-[10px] font-mono tracking-wider" onClick={() => setFilter(f)}>
            {f.toUpperCase()}
          </Button>
        ))}
      </div>

      <div className="space-y-2">
        {isLoading ? (
          <div className="p-8 flex justify-center"><div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>
        ) : filtered.length === 0 ? (
          <div className="bg-card border border-border rounded p-12 text-center">
            <CalendarDays className="w-8 h-8 mx-auto text-muted-foreground/40 mb-3" />
            <p className="font-mono text-sm text-muted-foreground">NO MEETINGS SCHEDULED</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Clear calendar for deep work</p>
          </div>
        ) : (
          filtered.map(meeting => {
            const stat = statusConfig[meeting.status] || statusConfig.scheduled;
            return (
              <div key={meeting.id} className="bg-card border border-border rounded p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium">{meeting.title}</p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1 font-mono">
                        <CalendarDays className="w-3 h-3" /> {format(parseLocalDate(meeting.date), 'MMM d, yyyy')}
                      </span>
                      {meeting.start_time && (
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" /> {meeting.start_time} – {meeting.end_time}
                        </span>
                      )}
                      {meeting.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {meeting.location}
                        </span>
                      )}
                      {meeting.attendees?.length > 0 && (
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" /> {meeting.attendees.length}
                        </span>
                      )}
                      {meeting.project_id && projectMap[meeting.project_id] && (
                        <span className="flex items-center gap-1">
                          <FolderKanban className="w-3 h-3" /> {projectMap[meeting.project_id].name}
                        </span>
                      )}
                      {meeting.is_recurring && (
                        <span className="flex items-center gap-1">
                          <Repeat className="w-3 h-3" /> {meeting.recurrence_pattern}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <Badge variant="outline" className={cn("text-[10px] font-mono", stat.class)}>{stat.label}</Badge>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEdit(meeting)}>
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(meeting)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                {meeting.description && <p className="text-xs text-muted-foreground mt-2">{meeting.description}</p>}
              </div>
            );
          })
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={(v) => { if (!v) closeDialog(); else setDialogOpen(true); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="font-mono text-sm tracking-wider">{editingMeeting ? 'EDIT MEETING' : 'SCHEDULE MEETING'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-[10px] font-mono tracking-widest">TITLE *</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div><Label className="text-[10px] font-mono tracking-widest">DATE</Label><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label className="text-[10px] font-mono tracking-widest">START</Label><Input type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} /></div>
              <div><Label className="text-[10px] font-mono tracking-widest">END</Label><Input type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} /></div>
            </div>
            <div><Label className="text-[10px] font-mono tracking-widest">LOCATION</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Room or link" /></div>
            <div>
              <Label className="text-[10px] font-mono tracking-widest">PROJECT</Label>
              <Select value={form.project_id} onValueChange={(v) => setForm({ ...form, project_id: v === 'none' ? '' : v })}>
                <SelectTrigger className="text-sm"><SelectValue placeholder="No project" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No project</SelectItem>
                  {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label className="text-[10px] font-mono tracking-widest">DESCRIPTION</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></div>
            <div className="flex items-center justify-between py-1">
              <Label className="text-[10px] font-mono tracking-widest">RECURRING</Label>
              <Switch checked={form.is_recurring} onCheckedChange={(v) => setForm({ ...form, is_recurring: v })} />
            </div>
            {form.is_recurring && (
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-mono tracking-widest">REPEATS</Label>
                  <Select value={form.recurrence_pattern} onValueChange={(v) => setForm({ ...form, recurrence_pattern: v })}>
                    <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Biweekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-[10px] font-mono tracking-widest">UNTIL</Label>
                  <Input type="date" value={form.recurrence_end_date} onChange={(e) => setForm({ ...form, recurrence_end_date: e.target.value })} />
                </div>
              </div>
            )}
            <Button className="w-full font-mono text-[10px] tracking-wider" disabled={!form.title} onClick={() => saveMutation.mutate(form)}>
              {editingMeeting ? 'UPDATE' : 'SCHEDULE'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => { if (!v) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-mono text-sm">DELETE MEETING</AlertDialogTitle>
            <AlertDialogDescription>Are you sure you want to delete "{deleteTarget?.title}"? This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="font-mono text-[10px] tracking-wider">CANCEL</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground font-mono text-[10px] tracking-wider" onClick={() => deleteMutation.mutate(deleteTarget.id)}>DELETE</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}