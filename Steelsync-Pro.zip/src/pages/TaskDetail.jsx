import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  ArrowLeft, Calendar, Clock, User, Tag, Paperclip, Link2, CheckSquare,
  AlertTriangle, Upload, RefreshCw, Trash2, Edit
} from 'lucide-react';
import { format } from 'date-fns';
import { parseLocalDate } from '@/utils';
import { cn } from '@/lib/utils';
import CommentThread from '../components/task/CommentThread';
import TaskFormDialog from '../components/project/TaskFormDialog';

const priorityConfig = {
  critical: { label: 'CRITICAL', class: 'bg-red-500/10 text-red-400 border-red-500/20' },
  high: { label: 'HIGH', class: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  medium: { label: 'MEDIUM', class: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  low: { label: 'LOW', class: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
};

const statusConfig = {
  backlog: { label: 'BACKLOG', class: 'bg-slate-500/10 text-slate-400' },
  todo: { label: 'TO DO', class: 'bg-blue-500/10 text-blue-400' },
  in_progress: { label: 'IN PROGRESS', class: 'bg-amber-500/10 text-amber-400' },
  review: { label: 'REVIEW', class: 'bg-purple-500/10 text-purple-400' },
  completed: { label: 'COMPLETED', class: 'bg-emerald-500/10 text-emerald-400' },
};

export default function TaskDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const pathParts = window.location.pathname.split('/');
  const projectId = pathParts[2];
  const taskId = pathParts[4];

  const [editOpen, setEditOpen] = useState(false);

  const { data: taskList = [] } = useQuery({
    queryKey: ['task', taskId],
    queryFn: () => base44.entities.Task.filter({ id: taskId }),
    enabled: !!taskId,
  });
  const task = taskList[0];

  const { data: allTasks = [] } = useQuery({
    queryKey: ['tasks', projectId],
    queryFn: () => base44.entities.Task.filter({ project_id: projectId }, '-created_date', 500),
    enabled: !!projectId,
    initialData: [],
  });

  const { data: comments = [] } = useQuery({
    queryKey: ['task-comments', taskId],
    queryFn: () => base44.entities.Comment.filter({ task_id: taskId }, '-created_date', 100),
    enabled: !!taskId,
    initialData: [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => base44.entities.Project.filter({ id: projectId }),
    enabled: !!projectId,
  });
  const project = projects[0];

  const toggleChecklistMutation = useMutation({
    mutationFn: ({ taskData, index }) => {
      const newChecklist = [...(taskData.checklist || [])];
      newChecklist[index] = { ...newChecklist[index], completed: !newChecklist[index].completed };
      return base44.entities.Task.update(taskData.id, { checklist: newChecklist });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['task', taskId] });
    },
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.Task.update(task.id, {
      file_urls: [...(task.file_urls || []), file_url],
    });
    queryClient.invalidateQueries({ queryKey: ['task', taskId] });
  };

  if (!task) {
    return (
      <div className="flex items-center justify-center h-full py-20">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const prio = priorityConfig[task.priority] || priorityConfig.medium;
  const status = statusConfig[task.status] || statusConfig.todo;
  const checklist = task.checklist || [];
  const checkDone = checklist.filter(c => c.completed).length;
  const checkProgress = checklist.length > 0 ? Math.round((checkDone / checklist.length) * 100) : 0;
  const isOverdue = task.due_date && parseLocalDate(task.due_date) < new Date() && task.status !== 'completed';
  const deps = (task.dependency_ids || []).map(id => allTasks.find(t => t.id === id)).filter(Boolean);

  return (
    <div className="p-4 lg:p-6 max-w-4xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Button variant="ghost" size="icon" className="mt-0.5" onClick={() => navigate(`/projects/${projectId}`)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-bold tracking-tight">{task.title}</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {project?.name && <span>{project.name} · </span>}
            Created {format(new Date(task.created_date), 'MMM d, yyyy')}
          </p>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5 text-xs flex-shrink-0" onClick={() => setEditOpen(true)}>
          <Edit className="w-3 h-3" /> Edit
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-4">
          {/* Description */}
          {task.description && (
            <div className="bg-card border border-border rounded p-4">
              <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground mb-2">DESCRIPTION</h3>
              <p className="text-sm whitespace-pre-wrap">{task.description}</p>
            </div>
          )}

          {/* Checklist */}
          {checklist.length > 0 && (
            <div className="bg-card border border-border rounded p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground flex items-center gap-2">
                  <CheckSquare className="w-3 h-3" /> CHECKLIST
                </h3>
                <span className="text-[10px] font-mono text-muted-foreground">{checkDone}/{checklist.length}</span>
              </div>
              <Progress value={checkProgress} className="h-1 mb-3" />
              <div className="space-y-1.5">
                {checklist.map((item, i) => (
                  <label
                    key={i}
                    className="flex items-center gap-2 p-1.5 rounded hover:bg-muted/30 transition-colors cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={item.completed}
                      onChange={() => toggleChecklistMutation.mutate({ taskData: task, index: i })}
                      className="rounded"
                    />
                    <span className={cn("text-sm", item.completed && "line-through text-muted-foreground")}>
                      {item.text}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Files */}
          <div className="bg-card border border-border rounded p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground flex items-center gap-2">
                <Paperclip className="w-3 h-3" /> FILES
              </h3>
              <label>
                <input type="file" className="hidden" onChange={handleFileUpload} />
                <Button variant="outline" size="sm" className="gap-1.5 text-xs cursor-pointer" asChild>
                  <span><Upload className="w-3 h-3" /> Upload</span>
                </Button>
              </label>
            </div>
            {(task.file_urls?.length > 0) ? (
              <div className="space-y-1">
                {task.file_urls.map((url, i) => (
                  <a
                    key={i}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 p-2 rounded hover:bg-muted/30 transition-colors text-xs text-primary"
                  >
                    <Paperclip className="w-3 h-3" />
                    <span className="truncate">{url.split('/').pop()}</span>
                  </a>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No files attached</p>
            )}
          </div>

          {/* Comments */}
          <div className="bg-card border border-border rounded p-4">
            <CommentThread comments={comments} taskId={taskId} />
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-3">
          <div className="bg-card border border-border rounded p-4 space-y-3">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-muted-foreground">STATUS</span>
              <Badge variant="outline" className={cn("block w-fit mt-1 text-[10px] font-mono", status.class)}>
                {status.label}
              </Badge>
            </div>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-muted-foreground">PRIORITY</span>
              <Badge variant="outline" className={cn("block w-fit mt-1 text-[10px] font-mono", prio.class)}>
                {prio.label}
              </Badge>
              {isOverdue && (
                <Badge variant="destructive" className="mt-1 text-[10px] font-mono gap-1">
                  <AlertTriangle className="w-3 h-3" /> OVERDUE
                </Badge>
              )}
            </div>

            {task.assignee && (
              <div>
                <span className="text-[10px] font-mono tracking-widest text-muted-foreground">ASSIGNEE</span>
                <p className="text-sm mt-1 flex items-center gap-1"><User className="w-3 h-3" /> {task.assignee}</p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {task.start_date && (
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-muted-foreground">START</span>
                  <p className="text-xs mt-1">{format(parseLocalDate(task.start_date), 'MMM d, yyyy')}</p>
                </div>
              )}
              {task.due_date && (
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-muted-foreground">DUE</span>
                  <p className={cn("text-xs mt-1", isOverdue && "text-red-400")}>
                    {format(parseLocalDate(task.due_date), 'MMM d, yyyy')}
                  </p>
                </div>
              )}
            </div>

            {(task.estimated_hours || task.actual_hours) && (
              <div>
                <span className="text-[10px] font-mono tracking-widest text-muted-foreground">TIME TRACKING</span>
                <p className="text-sm mt-1 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {task.actual_hours || 0}h / {task.estimated_hours || 0}h
                </p>
              </div>
            )}

            {task.is_recurring && (
              <div>
                <span className="text-[10px] font-mono tracking-widest text-muted-foreground">RECURRING</span>
                <p className="text-sm mt-1 flex items-center gap-1">
                  <RefreshCw className="w-3 h-3" /> {task.recurrence_pattern}
                </p>
              </div>
            )}

            {task.tags?.length > 0 && (
              <div>
                <span className="text-[10px] font-mono tracking-widest text-muted-foreground">TAGS</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {task.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-[10px] font-mono">{tag}</Badge>
                  ))}
                </div>
              </div>
            )}

            {deps.length > 0 && (
              <div>
                <span className="text-[10px] font-mono tracking-widest text-muted-foreground">DEPENDS ON</span>
                <div className="space-y-1 mt-1">
                  {deps.map(dep => (
                    <div key={dep.id} className="flex items-center gap-1 text-xs">
                      <Link2 className="w-3 h-3 text-muted-foreground" />
                      <span className={cn(dep.status === 'completed' ? 'line-through text-muted-foreground' : '')}>
                        {dep.title}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <TaskFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        projectId={projectId}
        task={task}
        allTasks={allTasks}
        members={project?.members || []}
      />
    </div>
  );
}