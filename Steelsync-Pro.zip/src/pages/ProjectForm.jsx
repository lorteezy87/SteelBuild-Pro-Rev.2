import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { ArrowLeft, Save, X, Plus } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function ProjectForm() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const editId = urlParams.get('edit');

  const [form, setForm] = useState({
    name: '', description: '', status: 'planning', start_date: '', end_date: '',
    client_name: '', location: '', budget: '', tags: [], members: [],
  });
  const [tagInput, setTagInput] = useState('');
  const [memberInput, setMemberInput] = useState('');

  const { data: existingProject } = useQuery({
    queryKey: ['project', editId],
    queryFn: () => editId ? base44.entities.Project.filter({ id: editId }) : null,
    enabled: !!editId,
  });

  useEffect(() => {
    if (existingProject && existingProject.length > 0) {
      const p = existingProject[0];
      setForm({
        name: p.name || '', description: p.description || '', status: p.status || 'planning',
        start_date: p.start_date || '', end_date: p.end_date || '',
        client_name: p.client_name || '', location: p.location || '',
        budget: p.budget || '', tags: p.tags || [], members: p.members || [],
      });
    }
  }, [existingProject]);

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const payload = { ...data, budget: data.budget ? Number(data.budget) : undefined };
      if (editId) return base44.entities.Project.update(editId, payload);
      return base44.entities.Project.create(payload);
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['projects-sidebar'] });
      navigate(editId ? `/projects/${editId}` : '/projects');
    },
  });

  const addTag = () => {
    if (tagInput.trim() && !form.tags.includes(tagInput.trim())) {
      setForm({ ...form, tags: [...form.tags, tagInput.trim()] });
      setTagInput('');
    }
  };

  const addMember = () => {
    if (memberInput.trim() && !form.members.includes(memberInput.trim())) {
      setForm({ ...form, members: [...form.members, memberInput.trim()] });
      setMemberInput('');
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-xl font-bold tracking-tight">{editId ? 'Edit Project' : 'New Project'}</h1>
          <p className="text-xs font-mono tracking-wider text-muted-foreground mt-0.5">
            {editId ? 'UPDATE DETAILS' : 'CREATE PROJECT'}
          </p>
        </div>
      </div>

      <div className="bg-card border border-border rounded p-4 lg:p-6 space-y-4">
        <div className="space-y-2">
          <Label className="text-xs font-mono tracking-wider">PROJECT NAME *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Highway 101 Bridge Repair" />
        </div>

        <div className="space-y-2">
          <Label className="text-xs font-mono tracking-wider">DESCRIPTION</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Project details..." rows={3} />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-xs font-mono tracking-wider">STATUS</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="planning">Planning</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="on_hold">On Hold</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-xs font-mono tracking-wider">CLIENT</Label>
            <Input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} placeholder="Client name" />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-xs font-mono tracking-wider">START DATE</Label>
            <Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label className="text-xs font-mono tracking-wider">END DATE</Label>
            <Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-xs font-mono tracking-wider">LOCATION</Label>
            <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Job site address" />
          </div>
          <div className="space-y-2">
            <Label className="text-xs font-mono tracking-wider">BUDGET ($)</Label>
            <Input type="number" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} placeholder="0" />
          </div>
        </div>

        {/* Tags */}
        <div className="space-y-2">
          <Label className="text-xs font-mono tracking-wider">TAGS</Label>
          <div className="flex gap-2">
            <Input value={tagInput} onChange={(e) => setTagInput(e.target.value)} placeholder="Add tag..." onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())} className="flex-1" />
            <Button type="button" variant="outline" size="sm" onClick={addTag}><Plus className="w-3 h-3" /></Button>
          </div>
          <div className="flex flex-wrap gap-1">
            {form.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs gap-1">
                {tag}
                <button onClick={() => setForm({ ...form, tags: form.tags.filter(t => t !== tag) })}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>

        {/* Members */}
        <div className="space-y-2">
          <Label className="text-xs font-mono tracking-wider">TEAM MEMBERS (Email)</Label>
          <div className="flex gap-2">
            <Input value={memberInput} onChange={(e) => setMemberInput(e.target.value)} placeholder="email@example.com" onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMember())} className="flex-1" />
            <Button type="button" variant="outline" size="sm" onClick={addMember}><Plus className="w-3 h-3" /></Button>
          </div>
          <div className="flex flex-wrap gap-1">
            {form.members.map((m) => (
              <Badge key={m} variant="secondary" className="text-xs gap-1">
                {m}
                <button onClick={() => setForm({ ...form, members: form.members.filter(x => x !== m) })}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex gap-2 pt-4">
          <Button onClick={() => saveMutation.mutate(form)} disabled={!form.name || saveMutation.isPending} className="gap-2 font-mono text-xs tracking-wider">
            <Save className="w-4 h-4" /> {saveMutation.isPending ? 'SAVING...' : 'SAVE PROJECT'}
          </Button>
          <Button variant="outline" onClick={() => navigate(-1)}>Cancel</Button>
        </div>
      </div>
    </div>
  );
}