import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Search, Plus, Mail, Archive, Circle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const priorityConfig = {
  urgent: { label: 'URGENT', class: 'bg-red-500/10 text-red-400 border-red-500/20' },
  high: { label: 'HIGH', class: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  normal: { label: 'NORMAL', class: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
  low: { label: 'LOW', class: 'bg-slate-500/10 text-slate-400 border-slate-500/20' },
};

export default function Inbox() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ subject: '', message: '', priority: 'normal' });

  const { data: threads = [], isLoading } = useQuery({
    queryKey: ['inbox'],
    queryFn: () => base44.entities.InboxThread.list('-created_date', 200),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.InboxThread.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['inbox'] }); setCreateOpen(false); setForm({ subject: '', message: '', priority: 'normal' }); },
  });

  const archiveMutation = useMutation({
    mutationFn: (id) => base44.entities.InboxThread.update(id, { status: 'archived' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['inbox'] }),
  });

  const markReadMutation = useMutation({
    mutationFn: (id) => base44.entities.InboxThread.update(id, { status: 'read' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['inbox'] }),
  });

  const filtered = threads.filter(t => {
    if (filter === 'unread' && t.status !== 'unread') return false;
    if (filter === 'archived' && t.status !== 'archived') return false;
    if (filter === 'active' && t.status === 'archived') return false;
    if (search && !t.subject.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const unreadCount = threads.filter(t => t.status === 'unread').length;

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl lg:text-2xl font-bold tracking-tight font-mono">INBOX</h1>
          <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
            {unreadCount} UNREAD · {threads.length} TOTAL THREADS
          </p>
        </div>
        <Button size="sm" className="gap-1.5 font-mono text-[10px] tracking-wider" onClick={() => setCreateOpen(true)}>
          <Plus className="w-3 h-3" /> NEW THREAD
        </Button>
      </div>

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search threads..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-8 text-xs" />
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="unread">Unread</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-card border border-border rounded divide-y divide-border">
        {isLoading ? (
          <div className="p-8 flex justify-center"><div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center">
            <Mail className="w-8 h-8 mx-auto text-muted-foreground/40 mb-3" />
            <p className="font-mono text-sm text-muted-foreground">NO THREADS</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Inbox is clear</p>
          </div>
        ) : (
          filtered.map(thread => {
            const prio = priorityConfig[thread.priority] || priorityConfig.normal;
            return (
              <div key={thread.id} className={cn("flex items-center gap-3 p-3 hover:bg-muted/30 transition-colors", thread.status === 'unread' && "bg-primary/5")}>
                <Circle className={cn("w-2 h-2 flex-shrink-0", thread.status === 'unread' ? "fill-primary text-primary" : "text-transparent")} />
                <div className="flex-1 min-w-0 cursor-pointer" onClick={() => thread.status === 'unread' && markReadMutation.mutate(thread.id)}>
                  <p className={cn("text-sm truncate", thread.status === 'unread' && "font-semibold")}>{thread.subject}</p>
                  <p className="text-xs text-muted-foreground truncate mt-0.5">{thread.message}</p>
                </div>
                <Badge variant="outline" className={cn("text-[10px] font-mono flex-shrink-0", prio.class)}>{prio.label}</Badge>
                <span className="text-[10px] text-muted-foreground font-mono flex-shrink-0">{format(new Date(thread.created_date), 'MMM d')}</span>
                <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0" onClick={() => archiveMutation.mutate(thread.id)}>
                  <Archive className="w-3 h-3" />
                </Button>
              </div>
            );
          })
        )}
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="font-mono text-sm tracking-wider">NEW THREAD</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
            <Textarea placeholder="Message..." rows={3} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
              <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
            <Button className="w-full font-mono text-[10px] tracking-wider" disabled={!form.subject} onClick={() => createMutation.mutate(form)}>
              CREATE THREAD
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}