import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Plus, Search, MapPin, Users, Calendar, Filter } from 'lucide-react';
import { format } from 'date-fns';
import { parseLocalDate } from '@/utils';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

const statusColors = {
  planning: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  on_hold: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  completed: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  archived: 'bg-muted text-muted-foreground border-border',
};

export default function Projects() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-created_date', 50),
    initialData: [],
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks-all'],
    queryFn: () => base44.entities.Task.list('-created_date', 500),
    initialData: [],
  });

  const filtered = projects.filter(p => {
    const matchSearch = p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.location?.toLowerCase().includes(search.toLowerCase()) ||
      p.client_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl lg:text-2xl font-bold tracking-tight">Projects</h1>
          <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
            {projects.length} TOTAL · {projects.filter(p => p.status === 'active').length} ACTIVE
          </p>
        </div>
        <Link to="/projects/new">
          <Button size="sm" className="gap-2 font-mono text-xs tracking-wider">
            <Plus className="w-4 h-4" /> NEW PROJECT
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-9 text-sm"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 h-9 text-sm">
            <Filter className="w-3 h-3 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="planning">Planning</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="on_hold">On Hold</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Project Grid */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-muted-foreground">No projects found</p>
          <Link to="/projects/new">
            <Button variant="outline" className="mt-4 gap-2">
              <Plus className="w-4 h-4" /> Create your first project
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {filtered.map((project) => {
            const projectTasks = tasks.filter(t => t.project_id === project.id);
            const completedCount = projectTasks.filter(t => t.status === 'completed').length;
            const progress = projectTasks.length > 0 ? Math.round((completedCount / projectTasks.length) * 100) : 0;

            return (
              <Link
                key={project.id}
                to={`/projects/${project.id}`}
                className="bg-card border border-border rounded p-4 hover:border-primary/30 transition-all group"
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-medium text-sm group-hover:text-primary transition-colors truncate pr-2">
                    {project.name}
                  </h3>
                  <Badge variant="outline" className={`text-[10px] font-mono flex-shrink-0 ${statusColors[project.status] || ''}`}>
                    {project.status?.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>

                {project.description && (
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{project.description}</p>
                )}

                <div className="flex items-center gap-3 text-[10px] text-muted-foreground mb-3">
                  {project.location && (
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {project.location}</span>
                  )}
                  {project.client_name && (
                    <span className="truncate">{project.client_name}</span>
                  )}
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {project.members?.length || 0}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Progress value={progress} className="h-1 flex-1" />
                  <span className="text-[10px] font-mono text-muted-foreground">{progress}%</span>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {completedCount}/{projectTasks.length} tasks
                </p>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}