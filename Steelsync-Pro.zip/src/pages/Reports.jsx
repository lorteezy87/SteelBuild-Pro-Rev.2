import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { cn } from '@/lib/utils';

const STATUS_COLORS = {
  backlog: '#64748b', todo: '#3b82f6', in_progress: '#f59e0b', review: '#a855f7', completed: '#10b981',
};
const PRIORITY_COLORS = {
  low: '#3b82f6', medium: '#f59e0b', high: '#f97316', critical: '#ef4444',
};

export default function Reports() {
  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks-all'],
    queryFn: () => base44.entities.Task.list('-created_date', 500),
    initialData: [],
  });
  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-created_date', 100),
    initialData: [],
  });

  const statusData = Object.entries(
    tasks.reduce((acc, t) => { acc[t.status] = (acc[t.status] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name: name.replace('_', ' ').toUpperCase(), value, fill: STATUS_COLORS[name] || '#64748b' }));

  const priorityData = Object.entries(
    tasks.reduce((acc, t) => { acc[t.priority] = (acc[t.priority] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name: name.toUpperCase(), value, fill: PRIORITY_COLORS[name] || '#64748b' }));

  const projectData = projects.slice(0, 10).map(p => {
    const pTasks = tasks.filter(t => t.project_id === p.id);
    const done = pTasks.filter(t => t.status === 'completed').length;
    return { name: p.name, total: pTasks.length, completed: done };
  });

  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const overdue = tasks.filter(t => t.due_date && new Date(t.due_date) < new Date() && t.status !== 'completed').length;

  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-xl lg:text-2xl font-bold tracking-tight font-mono">REPORTS</h1>
        <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
          OPERATIONS ANALYTICS & METRICS
        </p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'TOTAL TASKS', value: tasks.length },
          { label: 'COMPLETED', value: completedTasks },
          { label: 'COMPLETION RATE', value: tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) + '%' : '0%' },
          { label: 'OVERDUE', value: overdue },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded p-4">
            <p className="text-[10px] font-mono tracking-widest text-muted-foreground">{s.label}</p>
            <p className="text-2xl font-bold font-mono mt-1">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Status distribution */}
        <div className="bg-card border border-border rounded p-4">
          <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground mb-4">TASKS BY STATUS</h3>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                  {statusData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-xs text-muted-foreground text-center py-8">No data yet</p>}
        </div>

        {/* Priority distribution */}
        <div className="bg-card border border-border rounded p-4">
          <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground mb-4">TASKS BY PRIORITY</h3>
          {priorityData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={priorityData}>
                <XAxis dataKey="name" tick={{ fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="value" radius={[2, 2, 0, 0]}>
                  {priorityData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <p className="text-xs text-muted-foreground text-center py-8">No data yet</p>}
        </div>
      </div>

      {/* Project progress */}
      <div className="bg-card border border-border rounded p-4">
        <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground mb-4">PROJECT PROGRESS</h3>
        {projectData.length > 0 ? (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={projectData} layout="vertical">
              <XAxis type="number" tick={{ fontSize: 10 }} />
              <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 10 }} />
              <Tooltip />
              <Bar dataKey="total" fill="#3b82f6" radius={[0, 2, 2, 0]} name="Total" />
              <Bar dataKey="completed" fill="#10b981" radius={[0, 2, 2, 0]} name="Completed" />
            </BarChart>
          </ResponsiveContainer>
        ) : <p className="text-xs text-muted-foreground text-center py-8">No projects yet</p>}
      </div>
    </div>
  );
}