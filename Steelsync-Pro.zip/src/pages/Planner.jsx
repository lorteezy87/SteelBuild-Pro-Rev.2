import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Plus, Clock, ChevronLeft, ChevronRight, Check, Trash2 } from 'lucide-react';
import { format, addDays, subDays, isToday, isSameDay } from 'date-fns';
import { parseLocalDate } from '@/utils';
import { cn } from '@/lib/utils';

const typeConfig = {
  focus: { label: 'FOCUS', class: 'border-l-blue-500 bg-blue-500/5' },
  meeting: { label: 'MEETING', class: 'border-l-purple-500 bg-purple-500/5' },
  break: { label: 'BREAK', class: 'border-l-emerald-500 bg-emerald-500/5' },
  admin: { label: 'ADMIN', class: 'border-l-amber-500 bg-amber-500/5' },
  other: { label: 'OTHER', class: 'border-l-slate-500 bg-slate-500/5' },
};

export default function Planner() {
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ title: '', type: 'focus', start_time: '09:00', end_time: '10:00' });

  const dateStr = format(selectedDate, 'yyyy-MM-dd');

  const { data: blocks = [], isLoading } = useQuery({
    queryKey: ['planner', dateStr],
    queryFn: () => base44.entities.PlannerBlock.filter({ date: dateStr }, 'start_time', 50),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.PlannerBlock.create({ ...data, date: dateStr }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['planner', dateStr] }); setCreateOpen(false); setForm({ title: '', type: 'focus', start_time: '09:00', end_time: '10:00' }); },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, completed }) => base44.entities.PlannerBlock.update(id, { completed: !completed }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['planner', dateStr] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PlannerBlock.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['planner', dateStr] }),
  });

  return (
    <div className="p-4 lg:p-6 max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl lg:text-2xl font-bold tracking-tight font-mono">PLANNER</h1>
          <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
            FOCUS BLOCKS & DAILY SCHEDULE
          </p>
        </div>
        <Button size="sm" className="gap-1.5 font-mono text-[10px] tracking-wider" onClick={() => setCreateOpen(true)}>
          <Plus className="w-3 h-3" /> ADD BLOCK
        </Button>
      </div>

      {/* Date navigation */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedDate(subDays(selectedDate, 1))}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <span className="font-mono text-sm tracking-wider">
          {isToday(selectedDate) ? 'TODAY · ' : ''}{format(selectedDate, 'EEEE, MMMM d, yyyy').toUpperCase()}
        </span>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedDate(addDays(selectedDate, 1))}>
          <ChevronRight className="w-4 h-4" />
        </Button>
        {!isToday(selectedDate) && (
          <Button variant="outline" size="sm" className="h-7 text-[10px] font-mono" onClick={() => setSelectedDate(new Date())}>TODAY</Button>
        )}
      </div>

      {/* Blocks */}
      <div className="space-y-2">
        {isLoading ? (
          <div className="p-8 flex justify-center"><div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>
        ) : blocks.length === 0 ? (
          <div className="bg-card border border-border rounded p-12 text-center">
            <Clock className="w-8 h-8 mx-auto text-muted-foreground/40 mb-3" />
            <p className="font-mono text-sm text-muted-foreground">NO BLOCKS SCHEDULED</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Plan your day by creating focus blocks</p>
          </div>
        ) : (
          blocks.map(block => {
            const config = typeConfig[block.type] || typeConfig.other;
            return (
              <div key={block.id} className={cn("bg-card border border-border rounded border-l-4 p-3 flex items-center gap-3", config.class, block.completed && "opacity-50")}>
                <button onClick={() => toggleMutation.mutate({ id: block.id, completed: block.completed })} className={cn("w-5 h-5 rounded border flex items-center justify-center flex-shrink-0", block.completed ? "bg-primary border-primary" : "border-muted-foreground/30")}>
                  {block.completed && <Check className="w-3 h-3 text-primary-foreground" />}
                </button>
                <div className="flex-1 min-w-0">
                  <p className={cn("text-sm font-medium", block.completed && "line-through")}>{block.title}</p>
                  <div className="flex items-center gap-2 mt-0.5 text-[10px] font-mono text-muted-foreground">
                    <span>{block.start_time} – {block.end_time}</span>
                    <Badge variant="outline" className="text-[9px] font-mono">{config.label}</Badge>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-muted-foreground hover:text-destructive" onClick={() => deleteMutation.mutate(block.id)}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            );
          })
        )}
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="font-mono text-sm tracking-wider">NEW FOCUS BLOCK</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Block title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
              <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="focus">Focus</SelectItem>
                <SelectItem value="meeting">Meeting</SelectItem>
                <SelectItem value="break">Break</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            <div className="grid grid-cols-2 gap-2">
              <Input type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
              <Input type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
            </div>
            <Button className="w-full font-mono text-[10px] tracking-wider" disabled={!form.title} onClick={() => createMutation.mutate(form)}>
              CREATE BLOCK
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}