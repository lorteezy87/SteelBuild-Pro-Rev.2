import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Clock, CheckCircle, MessageSquare, FolderKanban, AlertTriangle, CalendarDays, Eye, Inbox } from 'lucide-react';
import { isToday, isPast } from 'date-fns';
import { parseLocalDate } from '@/utils';
import { cn } from '@/lib/utils';

function StatCard({ label, value, detail }) {
  return (
    <div className="bg-card border border-border rounded p-4">
      <p className="text-[10px] font-mono tracking-widest text-muted-foreground">{label}</p>
      <p className="text-2xl font-bold font-mono mt-1">{value}</p>
      {detail && <p className="text-[10px] text-muted-foreground mt-0.5">{detail}</p>}
    </div>
  );
}

function SectionCard({ title, subtitle, icon: Icon, emptyTitle, emptySubtitle, to }) {
  const Wrapper = to ? Link : 'div';
  return (
    <Wrapper to={to} className="bg-card border border-border rounded p-6 text-center hover:border-primary/20 transition-colors block">
      <p className="text-xs font-mono font-bold tracking-widest mb-0.5">{title}</p>
      <p className="text-[10px] text-muted-foreground">{subtitle}</p>
      <Icon className="w-8 h-8 mx-auto text-muted-foreground/30 mt-4 mb-3" />
      <p className="font-mono text-xs font-semibold">{emptyTitle}</p>
      <p className="text-[10px] text-muted-foreground mt-0.5">{emptySubtitle}</p>
    </Wrapper>
  );
}

export default function Dashboard() {
  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-created_date', 100),
    initialData: [],
  });
  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks-all'],
    queryFn: () => base44.entities.Task.list('-created_date', 500),
    initialData: [],
  });
  const { data: meetings = [] } = useQuery({
    queryKey: ['meetings'],
    queryFn: () => base44.entities.Meeting.list('-date', 50),
    initialData: [],
  });
  const { data: plannerBlocks = [] } = useQuery({
    queryKey: ['planner-today'],
    queryFn: () => {
      const today = new Date().toISOString().split('T')[0];
      return base44.entities.PlannerBlock.filter({ date: today }, 'start_time', 50);
    },
    initialData: [],
  });
  const { data: threads = [] } = useQuery({
    queryKey: ['inbox'],
    queryFn: () => base44.entities.InboxThread.list('-created_date', 100),
    initialData: [],
  });

  const activeTasks = tasks.filter(t => t.status !== 'completed');
  const activeProjects = projects.filter(p => p.status === 'active');
  const urgentThreads = threads.filter(t => t.priority === 'urgent' && t.status === 'unread');
  const todayMeetings = meetings.filter(m => isToday(parseLocalDate(m.date)));
  const overdueTasks = tasks.filter(t => t.due_date && isPast(parseLocalDate(t.due_date)) && t.status !== 'completed');
  const staleProjects = projects.filter(p => p.status !== 'completed' && p.status !== 'archived');
  const criticalAlerts = overdueTasks.length;

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-xl lg:text-2xl font-bold tracking-tight font-mono">COMMAND CENTER</h1>
        <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
          Real-time operations overview
        </p>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="ACTIVE TASKS" value={activeTasks.length} detail={`${tasks.length} total`} />
        <StatCard label="OPEN THREADS" value={threads.filter(t => t.status !== 'archived').length} detail={`${urgentThreads.length} urgent`} />
        <StatCard label="PROJECTS" value={`${projects.length}`} detail={`${activeProjects.length} active`} />
        <StatCard label="CRITICAL ALERTS" value={criticalAlerts} detail={criticalAlerts > 0 ? `${criticalAlerts} overdue tasks` : 'All clear'} />
      </div>

      {/* Middle Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        <SectionCard
          title="TODAY PLAN"
          subtitle={`${plannerBlocks.length} blocks scheduled`}
          icon={Clock}
          emptyTitle={plannerBlocks.length > 0 ? `${plannerBlocks.length} BLOCKS READY` : 'NO BLOCKS SCHEDULED'}
          emptySubtitle={plannerBlocks.length > 0 ? 'Daily plan is set' : 'Plan your day by creating focus blocks'}
          to="/planner"
        />
        <SectionCard
          title="FOLLOW-UPS DUE"
          subtitle={`${overdueTasks.length} pending actions`}
          icon={CheckCircle}
          emptyTitle={overdueTasks.length > 0 ? `${overdueTasks.length} ITEMS OVERDUE` : 'NO FOLLOW-UPS PENDING'}
          emptySubtitle={overdueTasks.length > 0 ? 'Action required' : 'All action items current'}
          to="/tasks"
        />
        <SectionCard
          title="PROJECT RISKS"
          subtitle={`${criticalAlerts} active signals`}
          icon={AlertTriangle}
          emptyTitle={criticalAlerts > 0 ? `${criticalAlerts} RISKS DETECTED` : 'NO CRITICAL RISKS'}
          emptySubtitle={criticalAlerts > 0 ? 'Review immediately' : 'Projects within parameters'}
          to="/projects"
        />
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        <SectionCard
          title="URGENT INBOX"
          subtitle={`${urgentThreads.length} priority threads`}
          icon={Inbox}
          emptyTitle={urgentThreads.length > 0 ? `${urgentThreads.length} URGENT MESSAGES` : 'NO URGENT MESSAGES'}
          emptySubtitle={urgentThreads.length > 0 ? 'Review priority threads' : 'All critical threads handled'}
          to="/inbox"
        />
        <SectionCard
          title="MEETINGS TODAY"
          subtitle={`${todayMeetings.length} scheduled`}
          icon={CalendarDays}
          emptyTitle={todayMeetings.length > 0 ? `${todayMeetings.length} MEETINGS SCHEDULED` : 'NO MEETINGS SCHEDULED'}
          emptySubtitle={todayMeetings.length > 0 ? 'Check your schedule' : 'Clear calendar for deep work'}
          to="/meetings"
        />
        <SectionCard
          title="NEGLECTED PROJECTS"
          subtitle={`${staleProjects.length > activeProjects.length ? staleProjects.length - activeProjects.length : 0} inactive`}
          icon={Eye}
          emptyTitle="ALL PROJECTS ACTIVE"
          emptySubtitle="No stale projects detected"
          to="/projects"
        />
      </div>
    </div>
  );
}