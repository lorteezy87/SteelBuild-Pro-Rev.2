import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Settings, MapPin, Calendar, Users, DollarSign } from 'lucide-react';
import { format } from 'date-fns';
import { parseLocalDate } from '@/utils';
import KanbanBoard from '../components/project/KanbanBoard';
import GanttChart from '../components/project/GanttChart';
import ProjectCalendar from '../components/project/ProjectCalendar';
import TaskFilterBar from '../components/project/TaskFilterBar';
import TaskFormDialog from '../components/project/TaskFormDialog';

const statusColors = {
  planning: 'bg-slate-500/10 text-slate-400',
  active: 'bg-emerald-500/10 text-emerald-400',
  on_hold: 'bg-amber-500/10 text-amber-400',
  completed: 'bg-blue-500/10 text-blue-400',
};

export default function ProjectDetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const projectId = window.location.pathname.split('/projects/')[1]?.split('/')[0];

  const [activeTab, setActiveTab] = useState('kanban');
  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('all');
  const [assignee, setAssignee] = useState('all');
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const { data: projects = [] } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => base44.entities.Project.filter({ id: projectId }),
    enabled: !!projectId,
  });
  const project = projects[0];

  const { data: tasks = [], isLoading: loadingTasks } = useQuery({
    queryKey: ['tasks', projectId],
    queryFn: () => base44.entities.Task.filter({ project_id: projectId }, '-created_date', 500),
    enabled: !!projectId,
    initialData: [],
  });

  const { data: comments = [] } = useQuery({
    queryKey: ['comments', projectId],
    queryFn: async () => {
      const taskIds = tasks.map(t => t.id);
      if (taskIds.length === 0) return [];
      const allComments = await base44.entities.Comment.list('-created_date', 500);
      return allComments.filter(c => taskIds.includes(c.task_id));
    },
    enabled: tasks.length > 0,
    initialData: [],
  });

  const filteredTasks = useMemo(() => {
    return tasks.filter(t => {
      const matchSearch = !search || t.title?.toLowerCase().includes(search.toLowerCase()) || t.description?.toLowerCase().includes(search.toLowerCase());
      const matchPriority = priority === 'all' || t.priority === priority;
      const matchAssignee = assignee === 'all' || (assignee === 'unassigned' ? !t.assignee : t.assignee === assignee);
      return matchSearch && matchPriority && matchAssignee;
    });
  }, [tasks, search, priority, assignee]);

  if (!project) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const completedCount = tasks.filter(t => t.status === 'completed').length;
  const progress = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  return (
    <div className="p-4 lg:p-6 space-y-4">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Button variant="ghost" size="icon" className="mt-0.5" onClick={() => navigate('/projects')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold tracking-tight truncate">{project.name}</h1>
            <Badge variant="outline" className={`text-[10px] font-mono ${statusColors[project.status] || ''}`}>
              {project.status?.replace('_', ' ').toUpperCase()}
            </Badge>
          </div>
          <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground flex-wrap">
            {project.location && (
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {project.location}</span>
            )}
            {project.client_name && <span>{project.client_name}</span>}
            {project.start_date && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" /> {format(parseLocalDate(project.start_date), 'MMM d, yyyy')}
                {project.end_date && ` — ${format(parseLocalDate(project.end_date), 'MMM d, yyyy')}`}
              </span>
            )}
            <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {project.members?.length || 0} members</span>
            {project.budget && (
              <span className="flex items-center gap-1"><DollarSign className="w-3 h-3" /> {project.budget.toLocaleString()}</span>
            )}
          </div>
          <div className="flex items-center gap-2 mt-2">
            <div className="h-1.5 flex-1 max-w-xs bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
            </div>
            <span className="text-[10px] font-mono text-muted-foreground">{completedCount}/{tasks.length} tasks · {progress}%</span>
          </div>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5 text-xs flex-shrink-0" onClick={() => navigate(`/projects/new?edit=${projectId}`)}>
          <Settings className="w-3 h-3" /> Edit
        </Button>
      </div>

      {/* Filter Bar */}
      <TaskFilterBar
        search={search} setSearch={setSearch}
        priority={priority} setPriority={setPriority}
        assignee={assignee} setAssignee={setAssignee}
        members={project.members || []}
        onNewTask={() => { setEditingTask(null); setTaskDialogOpen(true); }}
      />

      {/* Views */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-muted h-8">
          <TabsTrigger value="kanban" className="text-xs font-mono tracking-wider h-7">BOARD</TabsTrigger>
          <TabsTrigger value="gantt" className="text-xs font-mono tracking-wider h-7">TIMELINE</TabsTrigger>
          <TabsTrigger value="calendar" className="text-xs font-mono tracking-wider h-7">CALENDAR</TabsTrigger>
          <TabsTrigger value="list" className="text-xs font-mono tracking-wider h-7">LIST</TabsTrigger>
        </TabsList>

        <TabsContent value="kanban" className="mt-4">
          <KanbanBoard tasks={filteredTasks} projectId={projectId} comments={comments} />
        </TabsContent>

        <TabsContent value="gantt" className="mt-4">
          <div className="bg-card border border-border rounded overflow-hidden">
            <GanttChart tasks={filteredTasks} />
          </div>
        </TabsContent>

        <TabsContent value="calendar" className="mt-4">
          <ProjectCalendar tasks={filteredTasks} projectId={projectId} />
        </TabsContent>

        <TabsContent value="list" className="mt-4">
          <TaskListView tasks={filteredTasks} projectId={projectId} onEdit={(task) => { setEditingTask(task); setTaskDialogOpen(true); }} />
        </TabsContent>
      </Tabs>

      {/* Task Dialog */}
      <TaskFormDialog
        open={taskDialogOpen}
        onOpenChange={setTaskDialogOpen}
        projectId={projectId}
        task={editingTask}
        allTasks={tasks}
        members={project.members || []}
      />
    </div>
  );
}

function TaskListView({ tasks, projectId, onEdit }) {
  const priorityColors = {
    critical: 'text-red-400', high: 'text-orange-400', medium: 'text-amber-400', low: 'text-blue-400',
  };

  return (
    <div className="bg-card border border-border rounded divide-y divide-border">
      {tasks.length === 0 ? (
        <div className="p-8 text-center text-muted-foreground text-sm">No tasks found</div>
      ) : tasks.map(task => (
        <div
          key={task.id}
          className="flex items-center gap-3 p-3 hover:bg-muted/30 transition-colors cursor-pointer"
          onClick={() => onEdit(task)}
        >
          <div className={`w-2 h-2 rounded-full ${task.priority === 'critical' ? 'bg-red-500' : task.priority === 'high' ? 'bg-orange-500' : task.priority === 'medium' ? 'bg-amber-500' : 'bg-blue-500'}`} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{task.title}</p>
            <div className="flex items-center gap-2 mt-0.5 text-[10px] text-muted-foreground">
              <span className="font-mono uppercase">{task.status?.replace('_', ' ')}</span>
              {task.assignee && <span>· {task.assignee}</span>}
              {task.due_date && <span>· {format(parseLocalDate(task.due_date), 'MMM d')}</span>}
            </div>
          </div>
          {task.estimated_hours && (
            <span className="text-[10px] font-mono text-muted-foreground">
              {task.actual_hours || 0}/{task.estimated_hours}h
            </span>
          )}
        </div>
      ))}
    </div>
  );
}