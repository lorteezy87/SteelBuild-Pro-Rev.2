import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, CheckCheck, MessageSquare, UserPlus, AlertTriangle, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

const typeIcons = {
  task_assigned: UserPlus,
  task_updated: Clock,
  comment: MessageSquare,
  deadline: AlertTriangle,
  mention: Bell,
};

export default function Notifications() {
  const queryClient = useQueryClient();

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Notification.filter({ user_email: user.email }, '-created_date', 50);
    },
    initialData: [],
  });

  const markReadMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.update(id, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notifications-unread'] });
    },
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      const unread = notifications.filter(n => !n.is_read);
      await Promise.all(unread.map(n => base44.entities.Notification.update(n.id, { is_read: true })));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notifications-unread'] });
    },
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div className="p-4 lg:p-6 max-w-3xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Notifications</h1>
          <p className="text-xs font-mono tracking-wider text-muted-foreground mt-0.5">
            {unreadCount} UNREAD
          </p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={() => markAllReadMutation.mutate()}>
            <CheckCheck className="w-3 h-3" /> Mark all read
          </Button>
        )}
      </div>

      <div className="bg-card border border-border rounded divide-y divide-border">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground text-sm">
            <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
            No notifications
          </div>
        ) : (
          notifications.map((notif) => {
            const Icon = typeIcons[notif.type] || Bell;
            const link = notif.task_id && notif.project_id
              ? `/projects/${notif.project_id}/tasks/${notif.task_id}`
              : notif.project_id
              ? `/projects/${notif.project_id}`
              : null;

            const content = (
              <div
                className={cn(
                  "flex items-start gap-3 p-3 transition-colors cursor-pointer",
                  !notif.is_read ? "bg-primary/5" : "hover:bg-muted/30"
                )}
                onClick={() => !notif.is_read && markReadMutation.mutate(notif.id)}
              >
                <div className={cn("p-1.5 rounded", !notif.is_read ? "bg-primary/10" : "bg-muted")}>
                  <Icon className={cn("w-4 h-4", !notif.is_read ? "text-primary" : "text-muted-foreground")} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={cn("text-sm", !notif.is_read && "font-medium")}>{notif.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{notif.message}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(notif.created_date), { addSuffix: true })}
                  </p>
                </div>
                {!notif.is_read && (
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                )}
              </div>
            );

            return link ? (
              <Link key={notif.id} to={link}>{content}</Link>
            ) : (
              <div key={notif.id}>{content}</div>
            );
          })
        )}
      </div>
    </div>
  );
}