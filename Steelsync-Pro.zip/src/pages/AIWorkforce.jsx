import React, { useState } from 'react';
import { Bot, Zap, Brain, FileText, BarChart3, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import AgentChat from '@/components/agents/AgentChat';

const agents = [
  { id: 'task_assistant', name: 'TASK ASSISTANT', description: 'Automatically prioritize and assign tasks based on workload and deadlines', icon: Zap, color: 'text-blue-400 bg-blue-500/10' },
  { id: 'meeting_prep', name: 'MEETING PREP', description: 'Generate agendas, summarize notes, and extract action items from meetings', icon: MessageSquare, color: 'text-purple-400 bg-purple-500/10' },
  { id: 'risk_analyzer', name: 'RISK ANALYZER', description: 'Monitor projects for risks, delays, and budget overruns', icon: Brain, color: 'text-amber-400 bg-amber-500/10' },
  { id: 'report_generator', name: 'REPORT GENERATOR', description: 'Create weekly status reports and project summaries automatically', icon: FileText, color: 'text-emerald-400 bg-emerald-500/10' },
  { id: 'analytics_engine', name: 'ANALYTICS ENGINE', description: 'Track productivity metrics, project velocity, and team performance', icon: BarChart3, color: 'text-cyan-400 bg-cyan-500/10' },
  { id: 'daily_planner', name: 'DAILY PLANNER', description: 'Suggest optimal daily schedules based on tasks, meetings, and priorities', icon: Bot, color: 'text-rose-400 bg-rose-500/10' },
];

export default function AIWorkforce() {
  const [activeAgent, setActiveAgent] = useState(null);

  if (activeAgent) {
    return (
      <div className="h-[calc(100vh-64px)]">
        <AgentChat
          agentName={activeAgent.id}
          agentDisplayName={activeAgent.name}
          onBack={() => setActiveAgent(null)}
        />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-4">
      <div>
        <h1 className="text-xl lg:text-2xl font-bold tracking-tight font-mono">AI WORKFORCE</h1>
        <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
          {agents.length} AGENTS AVAILABLE · AUTONOMOUS OPERATIONS
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {agents.map(agent => (
          <div key={agent.id} className="bg-card border border-border rounded p-4 hover:border-primary/30 transition-colors">
            <div className="flex items-start gap-3">
              <div className={cn("w-10 h-10 rounded flex items-center justify-center flex-shrink-0", agent.color)}>
                <agent.icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-xs font-mono font-bold tracking-wider">{agent.name}</p>
                  <Badge variant="outline" className="text-[9px] font-mono text-emerald-400 border-emerald-500/20">
                    READY
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{agent.description}</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 font-mono text-[10px] tracking-wider"
              onClick={() => setActiveAgent(agent)}
            >
              OPEN CHAT
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}