import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Search, Calendar, User, FolderKanban, Plus, LayoutGrid, List, GanttChart, CalendarDays } from 'lucide-react';
import { format } from 'date-fns';
import { parseLocalDate } from '@/utils';
import { cn } from '@/lib/utils';
import TaskFormDialog from '@/components/project/TaskFormDialog';
import AllTasksKanban from '@/components/alltasks/AllTasksKanban';
import AllTasksTimeline from '@/components/alltasks/AllTasksTimeline';
import AllTasksCalendar from '@/components/alltasks/AllTasksCalendar';

const priorityConfig = {
  critical: { label: 'CRITICAL', class: 'bg-red-500/10 text-red-400 border-red-500/20' },
  high: { label: 'HIGH', class: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  medium: { label: 'MEDIUM', class: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  low: { label: 'LOW', class: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
};

const statusConfig = {
  backlog: { label: 'BACKLOG', class: 'bg-slate-500/10 text-slate-400' },
  todo: { label: 'TO DO', class: 'bg-blue-500/10 text-blue-400' },
  in_progress: { label: 'IN PROGRESS', class: 'bg-amber-500/10 text-amber-400' },
  review: { label: 'REVIEW', class: 'bg-purple-500/10 text-purple-400' },
  completed: { label: 'COMPLETED', class: 'bg-emerald-500/10 text-emerald-400' },
};

export default function AllTasks() {
  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('all');
  const [status, setStatus] = useState('all');
  const [projectFilter, setProjectFilter] = useState('all');
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [selectedProjectForNew, setSelectedProjectForNew] = useState(null);
  const [view, setView] = useState('list');

  const { data: tasks = [], isLoading: tasksLoading } = useQuery({
    queryKey: ['tasks-all'],
    queryFn: () => base44.entities.Task.list('-created_date', 500),
    initialData: [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects-all'],
    queryFn: () => base44.entities.Project.list('-created_date', 200),
    initialData: [],
  });

  const projectMap = useMemo(() => {
    const map = {};
    projects.forEach(p => { map[p.id] = p; });
    return map;
  }, [projects]);

  const filtered = useMemo(() => {
    return tasks.filter(t => {
      if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
      if (priority !== 'all' && t.priority !== priority) return false;
      if (status !== 'all' && t.status !== status) return false;
      if (projectFilter !== 'all' && t.project_id !== projectFilter) return false;
      return true;
    });
  }, [tasks, search, priority, status, projectFilter]);

  const now = new Date();

  if (tasksLoading) {
    return (
      <div className="flex items-center justify-center h-full py-20">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto space-y-4">
      <div>
        <h1 className="text-xl lg:text-2xl font-bold tracking-tight">All Tasks</h1>
        <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
          {filtered.length} TASK{filtered.length !== 1 ? 'S' : ''} · ALL PROJECTS
        </p>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap items-center">
        <Button
          size="sm"
          className="h-8 gap-1.5 font-mono text-[10px] tracking-wider"
          onClick={() => {
            setSelectedProjectForNew(projectFilter !== 'all' ? projectFilter : (projects[0]?.id || null));
            setTaskDialogOpen(true);
          }}
          disabled={projects.length === 0}
        >
          <Plus className="w-3 h-3" /> ADD TASK
        </Button>
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-8 text-xs"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="backlog">Backlog</SelectItem>
            <SelectItem value="todo">To Do</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="review">Review</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priority} onValueChange={setPriority}>
          <SelectTrigger className="w-28 h-8 text-xs">
            <SelectValue placeholder="Priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priority</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
        <Select value={projectFilter} onValueChange={setProjectFilter}>
          <SelectTrigger className="w-40 h-8 text-xs">
            <SelectValue placeholder="Project" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Projects</SelectItem>
            {projects.map(p => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex gap-0.5 ml-auto bg-muted rounded p-0.5">
          {[
            { id: 'list', icon: List, label: 'List' },
            { id: 'board', icon: LayoutGrid, label: 'Board' },
            { id: 'timeline', icon: GanttChart, label: 'Timeline' },
            { id: 'calendar', icon: CalendarDays, label: 'Calendar' },
          ].map(v => (
            <Button
              key={v.id}
              variant={view === v.id ? 'secondary' : 'ghost'}
              size="sm"
              className={cn("h-7 px-2 gap-1 text-[10px] font-mono tracking-wider", view === v.id && "bg-card shadow-sm")}
              onClick={() => setView(v.id)}
            >
              <v.icon className="w-3 h-3" /> <span className="hidden sm:inline">{v.label.toUpperCase()}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Views */}
      {view === 'list' && (
        <div className="bg-card border border-border rounded divide-y divide-border">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">No tasks match your filters.</div>
          ) : (
            filtered.map(task => {
              const project = projectMap[task.project_id];
              const prio = priorityConfig[task.priority] || priorityConfig.medium;
              const stat = statusConfig[task.status] || statusConfig.todo;
              const isOverdue = task.due_date && parseLocalDate(task.due_date) < now && task.status !== 'completed';
              return (
                <Link key={task.id} to={`/projects/${task.project_id}/tasks/${task.id}`} className="flex items-center gap-3 p-3 hover:bg-muted/30 transition-colors">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium truncate">{task.title}</span>
                      {isOverdue && <Badge variant="destructive" className="text-[9px] font-mono px-1.5 py-0">OVERDUE</Badge>}
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      {project && <span className="flex items-center gap-1"><FolderKanban className="w-3 h-3" /> {project.name}</span>}
                      {task.assignee && <span className="flex items-center gap-1"><User className="w-3 h-3" /> {task.assignee}</span>}
                      {task.due_date && <span className={cn("flex items-center gap-1", isOverdue && "text-red-400")}><Calendar className="w-3 h-3" /> {format(parseLocalDate(task.due_date), 'MMM d, yyyy')}</span>}
                    </div>
                  </div>
                  <Badge variant="outline" className={cn("text-[10px] font-mono flex-shrink-0", stat.class)}>{stat.label}</Badge>
                  <Badge variant="outline" className={cn("text-[10px] font-mono flex-shrink-0", prio.class)}>{prio.label}</Badge>
                </Link>
              );
            })
          )}
        </div>
      )}

      {view === 'board' && <AllTasksKanban tasks={filtered} projectMap={projectMap} />}
      {view === 'timeline' && <AllTasksTimeline tasks={filtered} projectMap={projectMap} />}
      {view === 'calendar' && <AllTasksCalendar tasks={filtered} />}
      {selectedProjectForNew && (
        <TaskFormDialog
          open={taskDialogOpen}
          onOpenChange={setTaskDialogOpen}
          projectId={selectedProjectForNew}
          task={null}
          allTasks={tasks}
          members={projectMap[selectedProjectForNew]?.members || []}
        />
      )}
    </div>
  );
}