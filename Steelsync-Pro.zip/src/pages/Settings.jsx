import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Mail, Bell, CheckCircle2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

export default function Settings() {
  const queryClient = useQueryClient();
  const [dailyEmail, setDailyEmail] = useState(false);

  const { data: user, isLoading } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  useEffect(() => {
    if (user) {
      setDailyEmail(!!user.daily_email_enabled);
    }
  }, [user]);

  const updateMutation = useMutation({
    mutationFn: (enabled) => base44.auth.updateMe({ daily_email_enabled: enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['current-user'] });
      toast({ title: 'Settings saved', description: 'Your notification preferences have been updated.' });
    },
  });

  const handleToggle = (checked) => {
    setDailyEmail(checked);
    updateMutation.mutate(checked);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full py-20">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-xl lg:text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-xs font-mono tracking-wider text-muted-foreground mt-1">
          NOTIFICATION PREFERENCES
        </p>
      </div>

      <div className="bg-card border border-border rounded divide-y divide-border">
        {/* Daily Email Summary */}
        <div className="p-4 flex items-start gap-4">
          <div className="p-2 rounded bg-primary/10 flex-shrink-0">
            <Mail className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium">Daily Email Summary</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Receive a daily email with overdue tasks, tasks due within 48 hours, and upcoming deadlines for the next 10 days.
                </p>
              </div>
              <Switch
                checked={dailyEmail}
                onCheckedChange={handleToggle}
                disabled={updateMutation.isPending}
              />
            </div>
            {dailyEmail && (
              <div className="flex items-center gap-1.5 mt-3 text-[10px] font-mono tracking-widest text-emerald-400">
                <CheckCircle2 className="w-3 h-3" /> ENABLED — SENT DAILY AT 7:00 AM
              </div>
            )}
          </div>
        </div>

        {/* In-App Notifications Info */}
        <div className="p-4 flex items-start gap-4">
          <div className="p-2 rounded bg-amber-500/10 flex-shrink-0">
            <Bell className="w-5 h-5 text-amber-400" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-medium">In-App Notifications</h3>
            <p className="text-xs text-muted-foreground mt-1">
              Task assignments, comments, and deadline alerts appear in your notification center automatically.
            </p>
            <span className="inline-block mt-2 text-[10px] font-mono tracking-widest text-muted-foreground">
              ALWAYS ACTIVE
            </span>
          </div>
        </div>
      </div>

      {user && (
        <div className="bg-card border border-border rounded p-4">
          <h3 className="text-[10px] font-mono tracking-widest text-muted-foreground mb-3">ACCOUNT</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Name</span>
              <span className="font-medium">{user.full_name || '—'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Email</span>
              <span className="font-medium">{user.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Role</span>
              <span className="font-mono text-xs uppercase tracking-wider">{user.role || 'user'}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}